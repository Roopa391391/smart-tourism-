import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Send, Mic, MapPin, Sparkles, AlertOctagon, HelpCircle, FileUp, Globe, CornerDownLeft, Volume2, User, CheckCircle2 } from "lucide-react";
import { Message } from "../types";

interface AIAssistantProps {
  currentLocation: string;
  setCurrentLocation: (loc: string) => void;
}

export default function AIAssistant({ currentLocation, setCurrentLocation }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I am **Tourism**, your autonomous security and response co-pilot. I am monitoring active risk reports, law enforcement bulletins, and local weather patterns around you.\n\nHow can I help protect or guide your transit path today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordTimer, setRecordTimer] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordTimer((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setRecordTimer(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording]);

  const sendMessage = async (textToSend?: string) => {
    const text = textToSend !== undefined ? textToSend : inputText;
    if (!text.trim() && !selectedFile) return;

    const userMessageId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMessageId,
      role: "user",
      content: text || "Transmitted file evaluation request...",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      fileAttached: selectedFile ? {
        name: selectedFile.name,
        type: selectedFile.type,
        size: selectedFile.size,
        url: fileUrl || ""
      } : undefined
    };

    setMessages((prev) => [...prev, newUserMessage]);
    if (textToSend === undefined) setInputText("");
    setSelectedFile(null);
    setFileUrl(null);
    setIsTyping(true);

    try {
      const response = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          location: currentLocation,
          messages: [...messages, newUserMessage].map((m) => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      if (!response.ok) throw new Error("Connection degraded");
      const data = await response.json();
      
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "⚠️ **Satellite connection lag detected.** Re-establishing redundant secure channel... In the meantime: Keep situational awareness, ensure you remain in public lit areas, or dial local emergency services if immediate threat exists.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleVoiceToggle = () => {
    if (isRecording) {
      setIsRecording(false);
      // Simulate voice-to-text translation
      setInputText("I need help locating the nearest police unit or hospital, I feel unsafe here");
    } else {
      setIsRecording(true);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setFileUrl(URL.createObjectURL(file));
    }
  };

  const triggerSuggestedPrompt = (prompt: string) => {
    sendMessage(prompt);
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins}:${rem < 10 ? '0' : ''}${rem}`;
  };

  const suggestions = [
    { title: "Zone Safety Lookup", text: "Is my current zone safe right now?", desc: "Risk index check" },
    { title: "Crime & Theft Index", text: "What risks should I know in this city?", desc: "Forecasting logs" },
    { title: "Emergency Hospital", text: "Find nearest official emergency hospitals near me", desc: "Response directions" },
    { title: "Local Laws Advice", text: "What are the local tourist rights and laws here?", desc: "Consulate protocols" }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 py-2 text-left font-sans h-[calc(100vh-140px)] min-h-[580px]">
      {/* Left Panel: Location Setting & Status Guidance */}
      <div className="lg:col-span-4 flex flex-col gap-5 h-full">
        {/* Active Coordinates Hub */}
        <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-xs p-5 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 space-y-4 shadow-md">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 rounded-full bg-blue-500 animate-pulse" />
            <h3 className="text-sm font-extrabold uppercase font-mono tracking-wider text-gray-500 dark:text-gray-400">Positioning Hub</h3>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block font-sans">Current Evaluated Landmark / City</label>
            <div className="relative">
              <MapPin className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-blue-500 h-4.5 w-4.5" />
              <input
                type="text"
                value={currentLocation}
                onChange={(e) => setCurrentLocation(e.target.value)}
                placeholder="e.g. Times Square, New York"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-805 bg-gray-50/50 dark:bg-slate-900/40 text-gray-800 dark:text-white font-medium text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <p className="text-[10px] text-gray-400 font-mono">
              AI adapts context, threat indexes, emergency dispatch numbers, and local hospitals automatically to this node.
            </p>
          </div>

          <div className="pt-3 border-t border-gray-150 dark:border-slate-800/60 space-y-2.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-gray-400">Network Sync Status</span>
              <span className="font-mono text-emerald-500 font-bold flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" /> Linked
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-gray-400">Response Guard Level</span>
              <span className="font-mono text-blue-500 font-bold uppercase tracking-wider bg-blue-500/10 px-1.5 py-0.5 rounded text-[10px]">Standard Protection</span>
            </div>
          </div>
        </div>

        {/* Suggested Prompts Grid */}
        <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-xs p-5 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 flex-1 flex flex-col gap-3 shadow-md">
          <div className="flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-blue-500" />
            <h4 className="text-xs font-extrabold uppercase font-mono tracking-wider text-gray-400">Interactive Diagnostics</h4>
          </div>
          <div className="grid grid-cols-1 gap-2.5 overflow-y-auto max-h-[300px] lg:max-h-[380px] pr-1">
            {suggestions.map((s, idx) => (
              <button
                key={idx}
                onClick={() => triggerSuggestedPrompt(s.text)}
                className="p-3 text-left rounded-xl bg-gray-50 hover:bg-blue-500/10 hover:border-blue-500/30 dark:bg-slate-900/40 dark:hover:bg-blue-950/20 border border-gray-200/20 dark:border-slate-800/70 transition-all cursor-pointer group space-y-1 block"
              >
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-850 dark:text-gray-200 group-hover:text-blue-500 font-display transition-colors">{s.title}</span>
                  <HelpCircle className="h-3.5 w-3.5 text-gray-400 group-hover:text-blue-500" />
                </div>
                <p className="text-[10px] text-gray-400 line-clamp-1">{s.text}</p>
                <div className="text-[9px] font-mono font-semibold tracking-widest uppercase text-blue-500/70">{s.desc}</div>
              </button>
            ))}
          </div>

          <div className="mt-auto pt-3 border-t border-gray-150 dark:border-slate-800/60 flex items-center gap-2 bg-amber-500/5 p-2 rounded-xl border border-amber-500/15">
            <AlertOctagon className="h-5 w-5 text-amber-500 shrink-0" />
            <p className="text-[10px] text-amber-700 dark:text-amber-400 leading-normal">
              <strong>Need Immediate Force Response?</strong> Head over to the Incident center for one-click direct authorities coordination.
            </p>
          </div>
        </div>
      </div>

      {/* Right Panel: Glassmorphic Floating Chat Core */}
      <div className="lg:col-span-8 flex flex-col bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-xs h-full rounded-3xl border border-gray-200/40 dark:border-slate-800/80 overflow-hidden shadow-md">
        {/* Chat Header */}
        <div className="px-5 py-4 border-b border-gray-155 dark:border-slate-800/60 flex justify-between items-center bg-gray-50/50 dark:bg-slate-900/10">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="h-10 w-10.5 rounded-xl premium-icon-container bg-gradient-to-tr from-blue-600 to-indigo-505 flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/10">
                <Sparkles className="h-4.5 w-4.5 text-blue-650 dark:text-blue-400 animate-pulse" />
              </div>
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-white dark:border-gray-950 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold font-display text-gray-800 dark:text-gray-100">Tourism Copilot</span>
                <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-blue-500/10 text-blue-500 border border-blue-500/20">Gemini 3.5</span>
              </div>
              <p className="text-[10px] text-gray-400 font-mono">Targeting Node: {currentLocation}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-blue-500" />
            <span className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-widest">Active Link</span>
          </div>
        </div>

        {/* Chat Message Scroll */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-sm scrollbar-thin scrollbar-thumb-gray-200">
          <AnimatePresence initial={false}>
            {messages.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 max-w-[85%] ${m.role === "user" ? "ml-auto flex-row-reverse text-right" : "mr-auto text-left"}`}
              >
                {/* Avatar */}
                <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${
                  m.role === "user"
                    ? "bg-blue-500 text-white"
                    : "bg-gray-100 dark:bg-gray-900 text-blue-500 border border-gray-200 dark:border-gray-800"
                }`}>
                  {m.role === "user" ? <User className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
                </div>

                <div className="space-y-1">
                  {/* Message bubble */}
                  <div className={`px-4 py-3 rounded-2xl leading-relaxed text-sm ${
                    m.role === "user"
                      ? "bg-blue-600 text-white rounded-tr-none text-left shadow-sm"
                      : "bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-900 text-gray-800 dark:text-gray-150 rounded-tl-none font-sans"
                  }`}>
                    {/* Markdown rendering simulation (simple parser for bolding and line breaks) */}
                    {m.content.split("\n\n").map((para, pIdx) => (
                      <p key={pIdx} className={pIdx > 0 ? "mt-2" : ""}>
                        {para.split("**").map((text, tIdx) => {
                          if (tIdx % 2 === 1) {
                            return <strong key={tIdx} className="font-extrabold text-blue-600 dark:text-emerald-400">{text}</strong>;
                          }
                          return text;
                        })}
                      </p>
                    ))}

                    {/* File Attachment Attachment display block */}
                    {m.fileAttached && (
                      <div className="mt-3 p-2 bg-black/10 dark:bg-black/40 rounded-lg flex items-center gap-2 border border-white/10 max-w-sm text-xs">
                        <FileUp className="h-4 w-4 text-emerald-400" />
                        <div className="truncate flex-1">
                          <p className="font-semibold truncate">{m.fileAttached.name}</p>
                          <p className="text-[10px] opacity-70 font-mono">{(m.fileAttached.size / 1024).toFixed(1)} KB</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Timestamp */}
                  <div className="text-[9px] text-gray-400 font-mono px-1">
                    {m.timestamp}
                  </div>
                </div>
              </motion.div>
            ))}

            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3 mr-auto items-center"
              >
                <div className="h-8 w-8 rounded-lg bg-gray-100 dark:bg-gray-900 flex items-center justify-center text-blue-500 border border-gray-200 dark:border-gray-800">
                  <Sparkles className="h-4 w-4 text-blue-500 animate-pulse" />
                </div>
                <div className="bg-gray-50 dark:bg-gray-900 px-4 py-2.5 rounded-2xl border border-gray-100 dark:border-gray-900 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>

        {/* Attached files preview bar */}
        {selectedFile && (
          <div className="px-5 py-2.5 bg-blue-500/5 dark:bg-blue-950/20 border-t border-gray-100 dark:border-gray-900 flex justify-between items-center text-xs">
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
              <FileUp className="h-4.5 w-4.5 animate-pulse" />
              <span className="font-semibold">{selectedFile.name}</span>
              <span className="font-mono text-[10px]">({(selectedFile.size / 1024).toFixed(1)} KB)</span>
            </div>
            <button
              onClick={() => { setSelectedFile(null); setFileUrl(null); }}
              className="text-gray-400 hover:text-red-500 font-semibold cursor-pointer"
            >
              Clear
            </button>
          </div>
        )}

        {/* Input Form Controls */}
        <div className="p-4 border-t border-gray-150 dark:border-gray-900 bg-gray-50/20 dark:bg-gray-950/20">
          <div className="flex gap-2.5 items-center">
            {/* Custom file mock trigger */}
            <label className="p-3 bg-gray-100 hover:bg-gray-200 dark:bg-gray-900 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 rounded-xl cursor-pointer transition-colors border border-gray-200/50 dark:border-gray-850">
              <FileUp className="h-5 w-5" />
              <input
                type="file"
                className="hidden"
                accept="image/*,video/*,audio/*"
                onChange={handleFileChange}
              />
            </label>

            {/* Voice stream dictation widget trigger */}
            <button
              onClick={handleVoiceToggle}
              className={`p-3 rounded-xl border transition-all cursor-pointer relative ${
                isRecording
                  ? "bg-red-500 hover:bg-red-650 text-white border-red-500 animate-pulse"
                  : "bg-gray-100 hover:bg-gray-200 dark:bg-gray-900 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 border-gray-200/50 dark:border-gray-850"
              }`}
            >
              <Mic className="h-5 w-5" />
              {isRecording && (
                <span className="absolute -top-7 left-1/2 transform -translate-x-1/2 bg-red-500 text-white font-mono font-bold text-[9px] px-1.5 py-0.5 rounded shadow">
                  {formatTimer(recordTimer)}
                </span>
              )}
            </button>

            {/* Large prompt block */}
            <div className="flex-1 relative">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask about safe transit pathways, medical services or city crime..."
                rows={1}
                className="w-full pr-12 pl-4 py-3 rounded-xl border border-gray-250 dark:border-gray-850 bg-white dark:bg-gray-900 text-gray-800 dark:text-white placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none min-h-[46px] max-h-[80px]"
              />
              <span className="absolute right-3.5 bottom-3.5 hidden md:flex items-center gap-0.5 text-[9px] font-mono text-gray-400">
                Shift
                <CornerDownLeft className="h-2.5 w-2.5" />
              </span>
            </div>

            {/* Submit Arrow */}
            <button
              onClick={() => sendMessage()}
              className="p-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-md transition-all active:scale-95 cursor-pointer border border-transparent"
              id="ai-assistant-send-btn"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
