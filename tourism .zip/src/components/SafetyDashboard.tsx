import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Shield, 
  MapPin, 
  AlertTriangle, 
  Users, 
  Compass, 
  Globe, 
  CheckCircle2, 
  ChevronRight, 
  Activity, 
  Zap, 
  RefreshCw, 
  Eye, 
  ArrowUpRight, 
  TrendingUp, 
  Mic, 
  Play, 
  Pause, 
  AlertOctagon, 
  RotateCcw, 
  Volume2, 
  ShieldAlert, 
  Award, 
  Grid,
  QrCode,
  User,
  ActivityIcon,
  Navigation,
  ShieldCheck,
  Siren,
  BellRing,
  HelpCircle,
  Search,
  Layers,
  Plus,
  Minus,
  Map
} from "lucide-react";

// Safe distance calculation formula in meters (Using Haversine formula)
function calculateDistanceInMeters(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371000; // Earth's radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

interface SafetyDashboardProps {
  currentLocation: string;
}

export default function SafetyDashboard({ currentLocation }: SafetyDashboardProps) {
  // --- Core States ---
  const [userName, setUserName] = useState(() => localStorage.getItem("traveler_name") || "Alexis Carter");
  const [userPlan, setUserPlan] = useState(() => localStorage.getItem("userPlan") || "Voyager Solo");
  const [bloodType, setBloodType] = useState(() => localStorage.getItem("traveler_bloodType") || "O Positive");
  const [allergies, setAllergies] = useState(() => localStorage.getItem("traveler_allergies") || "Penicillin, Peanuts");
  const [passportId] = useState("V-7298511");
  const [currentScore, setCurrentScore] = useState(94);
  const [threatLevel, setThreatLevel] = useState("Low");
  
  // --- Live GPS Tracking & Simulation ---
  const [gpsLatitude, setGpsLatitude] = useState(40.7580); // Center: Times Square node
  const [gpsLongitude, setGpsLongitude] = useState(-73.9855);
  const [isSimulatingPath, setIsSimulatingPath] = useState(false);
  const [bearing, setBearing] = useState(42);
  const [connectedSatellites, setConnectedSatellites] = useState(9);
  
  // --- Geo-Fence Settings ---
  const [fenceRadiusMeters, setFenceRadiusMeters] = useState(150); // Boundary fence
  const [anchorLatitude] = useState(40.7580); // Geofence Anchor center
  const [anchorLongitude] = useState(-73.9855);
  const [geoFenceBreached, setGeoFenceBreached] = useState(false);

  // --- SOS Alert State ---
  const [sosCountdown, setSosCountdown] = useState<number | null>(null);
  const [isSirenActive, setIsSirenActive] = useState(false);
  const [isSosTriggered, setIsSosTriggered] = useState(false);
  const [sosLogs, setSosLogs] = useState<string[]>([]);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // --- Voice Assistant & Command Capture State ---
  const [voiceQuery, setVoiceQuery] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [systemVoiceWarningText, setSystemVoiceWarningText] = useState("System online. Status verified secure.");
  const [speechError, setSpeechError] = useState<string | null>(null);

  // --- QR Code Modal State ---
  const [showQRModal, setShowQRModal] = useState(false);

  // --- Nearby Police Stations Filter State ---
  const [safeZoneFilter, setSafeZoneFilter] = useState<"all" | "police" | "close">("all");

  // --- Simulated Google Maps Specific States ---
  const [zoomLevel, setZoomLevel] = useState(15); // Zoom from 12 to 19
  const [mapType, setMapType] = useState<"roadmap" | "satellite" | "terrain" | "hybrid">("roadmap");
  const [showTrafficLayer, setShowTrafficLayer] = useState(true);
  const [isPegmanActive, setIsPegmanActive] = useState(false);
  const [mapSearchQuery, setMapSearchQuery] = useState("");
  const [mapSearchFocused, setMapSearchFocused] = useState(false);
  const [selectedMapMarker, setSelectedMapMarker] = useState<{ id: string; name: string; type: "hazard" | "safe"; note: string; distance: number } | null>(null);

  // --- Active Landmarks / Hazard Coordinates ---
  const primaryHazards = [
    { id: "haz-1", name: "Red Zone: Port District Corridor", lat: 40.7562, lng: -73.9890, threat_score: 83, risk_type: "Active Crime & Pedestrian Hazard" },
    { id: "haz-2", name: "Orange Zone: Central Market Jam", lat: 40.7595, lng: -73.9820, threat_score: 55, risk_type: "Severe Pickpocket Frequency" }
  ];

  const primarySafeZones = [
    { 
      id: "safe-1", 
      name: "Tourist Police Substation", 
      lat: 40.7570, 
      lng: -73.9860, 
      status: "Active Guard Presence", 
      type: "police" as const, 
      phone: "212-555-0199", 
      address: "42nd St & Broadway Kiosk",
      leftOffset: 45,
      leftZoomCoef: -2,
      topOffset: 68,
      topZoomCoef: 3,
      note: "Central visitor security desk. Dedicated armed tourist patrol division with English, Spanish and French translators on-shift."
    },
    { 
      id: "safe-2", 
      name: "Approved Hospitality Plaza", 
      lat: 40.7588, 
      lng: -73.9840, 
      status: "Secure Haven Synced", 
      type: "hospitality" as const, 
      phone: "212-555-0125", 
      address: "405 W 45th St, NY",
      leftOffset: 58,
      leftZoomCoef: 3,
      topOffset: 35,
      topZoomCoef: -1.5,
      note: "Elite hotel partnership under safe-corridor agreement. 24h locked vestibule with security screening and communication nodes."
    },
    { 
      id: "safe-3", 
      name: "Metropolitan Police Precinct 14", 
      lat: 40.7554, 
      lng: -73.9812, 
      status: "Rescue Operations Active", 
      type: "police" as const, 
      phone: "212-555-0144", 
      address: "357 W 35th St, NY",
      leftOffset: 32,
      leftZoomCoef: -4,
      topOffset: 50,
      topZoomCoef: 2,
      note: "Primary regional law enforcement precinct. Armed tactical Response Unit, temporary protective holding bays, and secure parking channels."
    },
    { 
      id: "safe-4", 
      name: "Times Square Police Command Kiosk", 
      lat: 40.7580, 
      lng: -73.9855, 
      status: "Rapid Dispatch Unit", 
      type: "police" as const, 
      phone: "212-555-0155", 
      address: "43rd St & Broadway, NY",
      leftOffset: 52,
      leftZoomCoef: 1,
      topOffset: 48,
      topZoomCoef: -1,
      note: "High-visibility public police kiosk. Real-time city surveillance integrations, emergency triage, and fast-response motorcycle escorts."
    },
    { 
      id: "safe-5", 
      name: "Port Authority Police Headquarters", 
      lat: 40.7568, 
      lng: -73.9905, 
      status: "Heavy Guard Detail", 
      type: "police" as const, 
      phone: "212-555-0188", 
      address: "625 8th Ave, NY",
      leftOffset: 18,
      leftZoomCoef: -5,
      topOffset: 60,
      topZoomCoef: 4,
      note: "Regional transit hub force. Officers equipped with emergency protective gears, high-density secure vestibules, and rapid exit tunnels."
    }
  ];

  // Sync profile options from LocalStorage periodically
  useEffect(() => {
    const handleProfileSync = () => {
      setUserName(localStorage.getItem("traveler_name") || "Alexis Carter");
      setUserPlan(localStorage.getItem("userPlan") || "Voyager Solo");
      setBloodType(localStorage.getItem("traveler_bloodType") || "O Positive");
      setAllergies(localStorage.getItem("traveler_allergies") || "Penicillin, Peanuts");
    };
    window.addEventListener("storage", handleProfileSync);
    return () => window.removeEventListener("storage", handleProfileSync);
  }, []);

  // --- Distance & Math Engine ---
  // Find distance to the closest hazard zone
  const distancesToHazards = primaryHazards.map(h => ({
    name: h.name,
    distance: calculateDistanceInMeters(gpsLatitude, gpsLongitude, h.lat, h.lng),
    score: h.threat_score
  }));
  const closestHazard = distancesToHazards.reduce((prev, curr) => prev.distance < curr.distance ? prev : curr);

  // Calculate distance from Geofence anchor
  const distanceFromGeofenceAnchor = calculateDistanceInMeters(gpsLatitude, gpsLongitude, anchorLatitude, anchorLongitude);

  // --- Safety Score calculation formula dynamically updated matching closest hazard distance
  useEffect(() => {
    let score = 98;
    
    // Penalize if far from geofence boundary
    if (distanceFromGeofenceAnchor > fenceRadiusMeters) {
      score -= Math.min(30, Math.round((distanceFromGeofenceAnchor - fenceRadiusMeters) / 5));
    }

    // Penalize heavily if near standard danger zone
    if (closestHazard.distance < 120) {
      score -= Math.max(10, Math.round((120 - closestHazard.distance) * 0.6));
    }

    const calculatedScore = Math.max(10, Math.min(100, score));
    setCurrentScore(calculatedScore);

    if (calculatedScore > 80) setThreatLevel("Low");
    else if (calculatedScore > 55) setThreatLevel("Moderate");
    else setThreatLevel("High");

  }, [gpsLatitude, gpsLongitude, fenceRadiusMeters, distanceFromGeofenceAnchor, closestHazard.distance]);

  // --- Dynamic Geo-Fence breach analyzer and voice warnings announcer ---
  useEffect(() => {
    const breached = distanceFromGeofenceAnchor > fenceRadiusMeters;
    if (breached !== geoFenceBreached) {
      setGeoFenceBreached(breached);
      if (breached) {
        announceVoiceWarning("Warning: You have breached the secure geofence boundaries. Please turn back immediately.");
        setSystemVoiceWarningText("GEOFENCE CONTAINMENT BREACH DETECTED.");
      } else {
        announceVoiceWarning("Geofence perimeter re-secured. Safe coverage active.");
        setSystemVoiceWarningText("System parameters stable within geofence boundaries.");
      }
    }
  }, [distanceFromGeofenceAnchor, fenceRadiusMeters, geoFenceBreached]);

  // Close proximity warnings trigger (less than 60 meters to danger)
  useEffect(() => {
    if (closestHazard.distance < 60) {
      const hazardShortName = closestHazard.name.split(":")[1] || "Hazard area";
      setSystemVoiceWarningText(`DANGER ZONE PROXIMITY ALERT: ${closestHazard.distance}m to ${hazardShortName}`);
      // Throttle speaking slightly using a lock or just fire once
      const speakKey = `speak_${closestHazard.name}_${Math.floor(closestHazard.distance / 15)}`;
      const hasSpokenRecently = sessionStorage.getItem(speakKey);
      if (!hasSpokenRecently) {
        announceVoiceWarning(`Caution: You are within ${closestHazard.distance} meters of danger zone, ${hazardShortName}. Maintain situational awareness.`);
        sessionStorage.setItem(speakKey, "true");
      }
    }
  }, [closestHazard.distance, closestHazard.name]);

  // --- Web Audio Oscillator Siren Synth Engine ---
  const audioContextRef = useRef<AudioContext | null>(null);
  const primaryOscillatorRef = useRef<OscillatorNode | null>(null);
  const secondaryOscillatorRef = useRef<OscillatorNode | null>(null);
  const sirenGainRef = useRef<GainNode | null>(null);
  const sirenTimerRef = useRef<any>(null);

  const startSirenOscillator = () => {
    try {
      if (audioContextRef.current) return; // Already running

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioContextRef.current = ctx;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.35, ctx.currentTime + 0.15);
      gain.connect(ctx.destination);
      sirenGainRef.current = gain;

      // Base carrier oscillator frequency
      const osc1 = ctx.createOscillator();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(580, ctx.currentTime);
      osc1.connect(gain);
      osc1.start();
      primaryOscillatorRef.current = osc1;

      // Sub-harmonic vibrato oscillator frequency
      const osc2 = ctx.createOscillator();
      osc2.type = "sawtooth";
      osc2.frequency.setValueAtTime(440, ctx.currentTime);
      osc2.connect(gain);
      osc2.start();
      secondaryOscillatorRef.current = osc2;

      // Wailing frequency modulation interval sweep
      let phase = 0;
      sirenTimerRef.current = setInterval(() => {
        if (!ctx || !osc1 || !osc2) return;
        const now = ctx.currentTime;
        if (phase === 0) {
          osc1.frequency.exponentialRampToValueAtTime(1100, now + 0.38);
          osc2.frequency.exponentialRampToValueAtTime(800, now + 0.38);
          phase = 1;
        } else {
          osc1.frequency.exponentialRampToValueAtTime(550, now + 0.38);
          osc2.frequency.exponentialRampToValueAtTime(380, now + 0.38);
          phase = 0;
        }
      }, 400);

      setIsSirenActive(true);
    } catch (e) {
      console.error("Native Audio Sirens unsupported or blocked:", e);
    }
  };

  const stopSirenOscillator = () => {
    if (sirenTimerRef.current) clearInterval(sirenTimerRef.current);
    if (sirenGainRef.current && audioContextRef.current) {
      try {
        sirenGainRef.current.gain.linearRampToValueAtTime(0, audioContextRef.current.currentTime + 0.1);
      } catch (e){}
    }
    setTimeout(() => {
      if (primaryOscillatorRef.current) { try { primaryOscillatorRef.current.stop(); } catch(e){} }
      if (secondaryOscillatorRef.current) { try { secondaryOscillatorRef.current.stop(); } catch(e){} }
      if (audioContextRef.current) { try { audioContextRef.current.close(); } catch(e){} }
      
      primaryOscillatorRef.current = null;
      secondaryOscillatorRef.current = null;
      audioContextRef.current = null;
      sirenGainRef.current = null;
    }, 120);
    setIsSirenActive(false);
  };

  // --- Dynamic Speech Synthesizer API ---
  const announceVoiceWarning = (phraseText: string) => {
    if ("speechSynthesis" in window) {
      // Silence any lingering statements to prevent overlaps
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(phraseText);
      utterance.rate = 0.95;
      utterance.pitch = 1.05;
      window.speechSynthesis.speak(utterance);
    } else {
      console.log("Announcement vocalized: ", phraseText);
    }
  };

  // --- Voice Command Inputs Capture (Speech Recognition API) ---
  const handleMicrophoneVoiceInput = () => {
    setSpeechError(null);
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      // Mocked Command System simulation if speech recognition is unsupported in iframe environment
      setIsListening(true);
      const simulatedKeywords = [
        "Trigger SOS Panic Alert",
        "Configure 300m Geofence",
        "Navigate North Corridor",
        "Announce Current Coordinates"
      ];
      // Type in text
      let step = 0;
      const t = setInterval(() => {
        setVoiceQuery(prev => simulatedKeywords[Math.floor(Date.now() / 1500) % simulatedKeywords.length].substring(0, step++));
        if (step > 25) {
          clearInterval(t);
          setIsListening(false);
          executeVoiceCommand();
        }
      }, 50);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.lang = "en-US";
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceQuery("Listening carefully...");
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event);
        setSpeechError("Mic access restricted or missing.");
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onresult = (event: any) => {
        const textResult = event.results[0][0].transcript;
        setVoiceQuery(textResult);
        // Process textResult
        processVocalQuery(textResult);
      };

      recognition.start();
    } catch(err) {
      setSpeechError("Speech engine locked.");
      setIsListening(false);
    }
  };

  const processVocalQuery = (text: string) => {
    const query = text.toLowerCase();
    if (query.includes("sos") || query.includes("panic") || query.includes("help")) {
      triggerActiveSOSCountdown();
      announceVoiceWarning("Initializing voice-activated SOS alarm.");
    } else if (query.includes("geofence") || query.includes("radius") || query.includes("fence")) {
      setFenceRadiusMeters(250);
      announceVoiceWarning("Adjusting geofence boundary range to 250 meters.");
    } else if (query.includes("clear") || query.includes("silence") || query.includes("quiet")) {
      resetSOSSystems();
      announceVoiceWarning("Silencing active alarms.");
    } else {
      announceVoiceWarning(`Analyzing safety command. ${text}`);
    }
  };

  const executeVoiceCommand = () => {
    processVocalQuery(voiceQuery);
  };

  // --- Coordinate Path Simulation Engine (Live GPS Tracking) ---
  useEffect(() => {
    let simulatorTimer: any = null;
    if (isSimulatingPath) {
      let increment = 1;
      simulatorTimer = setInterval(() => {
        // Drifts user slowly north and west towards the Port district danger zone
        setGpsLatitude(prev => prev - 0.00015);
        setGpsLongitude(prev => prev - 0.00022);
        setBearing(prev => (prev + 12) % 360);
        setConnectedSatellites(prev => Math.min(12, Math.max(6, prev + (Math.random() > 0.5 ? 1 : -1))));
        increment++;
      }, 1500);
    }
    return () => {
      if (simulatorTimer) clearInterval(simulatorTimer);
    };
  }, [isSimulatingPath]);

  // Manual nudge buttons to demonstrate live distance calculations seamlessly
  const handleManualNudge = (direction: "N" | "S" | "E" | "W") => {
    const step = 0.00025;
    if (direction === "N") setGpsLatitude(prev => prev + step);
    if (direction === "S") setGpsLatitude(prev => prev - step);
    if (direction === "E") setGpsLongitude(prev => prev + step);
    if (direction === "W") setGpsLongitude(prev => prev - step);
    setBearing(direction === "N" ? 0 : direction === "S" ? 180 : direction === "E" ? 90 : 270);
  };

  const resetManualGps = () => {
    setGpsLatitude(40.7580);
    setGpsLongitude(-73.9855);
    setBearing(42);
    setConnectedSatellites(10);
    setSystemVoiceWarningText("User tracking point reset to Center Anchor.");
    announceVoiceWarning("GPS coordinate grid centered.");
  };

  // --- SOS Logic countdown triggers ---
  const triggerActiveSOSCountdown = () => {
    if (sosCountdown !== null || isSosTriggered) return;
    setSosCountdown(5);
    setSosLogs(prev => [`[${new Date().toLocaleTimeString()}] Local SOS beacon initialized.`, ...prev]);

    countdownIntervalRef.current = setInterval(() => {
      setSosCountdown(prev => {
        if (prev === null) return null;
        if (prev <= 1) {
          clearInterval(countdownIntervalRef.current!);
          fireActiveSOS();
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const fireActiveSOS = () => {
    setIsSosTriggered(true);
    startSirenOscillator();
    setSosLogs(prev => [
      `[${new Date().toLocaleTimeString()}] SATELLITE ALERT DISPATCHED.`,
      `[${new Date().toLocaleTimeString()}] AI Voice warnings transmitting standard credentials...`,
      `[${new Date().toLocaleTimeString()}] Audio Siren synth nodes vibrating physical lines.`,
      ...prev
    ]);
    announceVoiceWarning(`Emergency SOS Active! Broadcasting coordinates ${gpsLatitude.toFixed(4)}, ${gpsLongitude.toFixed(4)} and medical profile. First responders notified!`);
  };

  const resetSOSSystems = () => {
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    setSosCountdown(null);
    setIsSosTriggered(false);
    stopSirenOscillator();
    setSosLogs(prev => [`[${new Date().toLocaleTimeString()}] Alarms deactivated safely.`, ...prev]);
  };

  return (
    <div className="space-y-8 py-2 text-left font-sans">
      
      {/* Top Interactive Warning HUD Banner */}
      <AnimatePresence>
        {(geoFenceBreached || isSosTriggered) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className={`p-4 rounded-2xl flex items-center justify-between gap-4 border text-white ${
              isSosTriggered 
                ? "bg-red-650 border-red-500 animate-pulse shadow-[0_0_25px_rgba(239,68,68,0.3)] bg-gradient-to-r from-red-650 to-rose-600" 
                : "bg-amber-600 border-amber-500 shadow-md bg-gradient-to-r from-amber-600 to-orange-500"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl shrink-0">
                <ShieldAlert className="h-6 w-6 text-white animate-spin" style={{ animationDuration: "3s" }} />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-black font-mono tracking-widest uppercase">
                  {isSosTriggered ? "CRITICAL OUT-OF-BOUNDS SOS BEACON FIRING" : "GEO-FENCE BOUNDARY DISCONNECTED"}
                </h4>
                <p className="text-xs text-white/90 font-medium">
                  {isSosTriggered 
                    ? `Transmitting Coordinates (${gpsLatitude.toFixed(4)}, ${gpsLongitude.toFixed(4)}) to Metropolitan Substation.` 
                    : `You are ${distanceFromGeofenceAnchor}m from anchor. Geofence radius: ${fenceRadiusMeters}m.`}
                </p>
              </div>
            </div>
            <button
              onClick={resetSOSSystems}
              className="px-4 py-2 bg-white text-gray-900 hover:bg-gray-100 rounded-xl text-xs font-black uppercase tracking-wider shadow cursor-pointer transition-transform scale-100 hover:scale-103"
            >
              SILENCE WARNING
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Grid: Telemetry map, passes, SOS panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* LEFT COLUMN: Map tracker and GPS (8 cols) */}
        <div className="lg:col-span-8 flex flex-col justify-between space-y-6">
          
          {/* Active Canvas Map Box */}
          <div className="bg-white dark:bg-[#070c20]/60 backdrop-blur-md p-6 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 flex flex-col justify-between shadow-md relative overflow-hidden flex-1 min-h-[460px]">
            
            {/* Top row controls */}
            <div className="flex justify-between items-center z-10 relative">
              <div className="space-y-0.5">
                <span className="text-[10px] font-black font-mono tracking-widest text-blue-500 uppercase flex items-center gap-1">
                  <Activity className="h-3 w-3 animate-pulse" /> TARGET SATELLITE HUD
                </span>
                <h3 className="text-lg font-extrabold font-display text-gray-900 dark:text-white">Active Precision Map</h3>
              </div>

              {/* Simulation State Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => setIsSimulatingPath(!isSimulatingPath)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1 px-3 py-2 cursor-pointer transition-all ${
                    isSimulatingPath 
                      ? "bg-amber-500 text-white shadow-md animate-pulse" 
                      : "bg-gray-100 hover:bg-gray-200 dark:bg-slate-900 dark:hover:bg-slate-850 dark:text-gray-200 border border-transparent dark:border-slate-800"
                  }`}
                  title="Simulate walking path towards the danger zone"
                >
                  {isSimulatingPath ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  <span>{isSimulatingPath ? "Simulating GPS Drifts" : "Simulate GPS Drift"}</span>
                </button>
                <button
                  onClick={resetManualGps}
                  className="p-2 bg-gray-100 hover:bg-gray-205 dark:bg-slate-900 dark:hover:bg-slate-800 rounded-xl dark:border dark:border-slate-800 text-gray-500 cursor-pointer"
                  title="Recenter tracking point"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Simulated Google Map Interactive Layout Container */}
            <div className="my-6 min-h-[350px] rounded-3xl border border-gray-150 dark:border-slate-800/80 relative overflow-hidden flex flex-col justify-end bg-slate-900 shadow-inner">
              
              {/* Actual Map Canvas Layers (Roadmap vs Satellite vs Terrain vs Hybrid) */}
              <div 
                className={`absolute inset-0 transition-all duration-700 ${
                  mapType === "satellite" 
                    ? "bg-[#04081c] bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:20px_20px]" 
                    : mapType === "terrain"
                      ? "bg-stone-150 dark:bg-[#111322] bg-[radial-gradient(#d6d3d1_1.5px,transparent_1.5px)] [background-size:16px_16px]"
                      : mapType === "hybrid"
                        ? "bg-[#020512] bg-[radial-gradient(#334155_1.2px,transparent_1.2px)] [background-size:24px_24px] border-double"
                        : "bg-[#f1efeb] dark:bg-[#070b1e]" // standard roadmap colors matching custom color pallet
                }`}
              >
                {/* Simulated Street Outlines (Vector Graphics representation) */}
                <svg className="absolute inset-0 w-full h-full opacity-40 pointer-events-none stroke-current text-gray-300 dark:text-slate-850" strokeWidth="4">
                  {/* Broadway Avenue */}
                  <line x1="-100" y1="50" x2="800" y2="400" className="stroke-gray-400 dark:stroke-slate-800" strokeWidth="10" />
                  {/* 42nd Street cross-street */}
                  <line x1="200" y1="-50" x2="100" y2="500" strokeWidth="8" />
                  {/* 45th Street cross-street */}
                  <line x1="450" y1="-50" x2="350" y2="500" strokeWidth="8" />
                  {/* Central Market Avenue */}
                  <line x1="-50" y1="300" x2="900" y2="180" strokeWidth="7" />
                  {/* Riverside highway line */}
                  <path d="M 50 450 Q 300 200 700 450" fill="none" className="stroke-indigo-300/60 dark:stroke-slate-800/80" strokeWidth="15" />
                </svg>

                {/* Google Maps Traffic Overlay Path Indicators (Interactive Layer) */}
                {showTrafficLayer && (
                  <svg className="absolute inset-0 w-full h-full opacity-70 pointer-events-none animate-pulse" style={{ animationDuration: "3.5s" }}>
                    {/* Green safe clear street channels */}
                    <line x1="-100" y1="50" x2="800" y2="400" className="stroke-emerald-500" strokeWidth="3" strokeDasharray="6 4" />
                    {/* Orange Pickpockets Crowd avenue heavy congestion flow */}
                    <line x1="-50" y1="300" x2="900" y2="180" className="stroke-amber-500" strokeWidth="5" strokeDasharray="3 3" />
                    {/* Red Port corridor active danger warning traffic block */}
                    <line x1="200" y1="-50" x2="100" y2="500" className="stroke-red-500" strokeWidth="4.5" />
                    {/* Quick navigation path line to safety when a destination marker is selected */}
                    {selectedMapMarker && selectedMapMarker.type === "safe" && (
                      <path 
                        d={`M ${(gpsLongitude + 73.9899) * 22000 * (zoomLevel / 15)} ${(40.7615 - gpsLatitude) * 22000 * (zoomLevel / 15)} L 380 180`}
                        fill="none" 
                        className="stroke-blue-500 animate-pulse" 
                        strokeWidth="5" 
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    )}
                  </svg>
                )}

                {/* Satellite terrain relief shadows overlay for satellite view style */}
                {(mapType === "satellite" || mapType === "hybrid") && (
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30 pointer-events-none mix-blend-multiply" />
                )}

                {/* Topographical contour elevation indicators for terrain style */}
                {mapType === "terrain" && (
                  <svg className="absolute inset-0 w-full h-full opacity-25 pointer-events-none stroke-stone-400 dark:stroke-slate-700" strokeWidth="1">
                    <circle cx="200" cy="150" r="100" fill="none" />
                    <circle cx="200" cy="150" r="140" fill="none" />
                    <circle cx="550" cy="220" r="80" fill="none" />
                    <circle cx="550" cy="220" r="120" fill="none" />
                  </svg>
                )}
              </div>

              {/* FLOATING HUD 1: Google Maps Search capsule overlay */}
              <div className="absolute top-4 left-4 z-30 max-w-[280px] w-full">
                <div className="bg-white dark:bg-slate-900 border border-gray-200/60 dark:border-slate-800 shadow-xl rounded-2xl flex items-center p-1 px-2.5 gap-2 relative">
                  <Search className="h-4 w-4 text-gray-400 shrink-0" />
                  <input
                    type="text"
                    value={mapSearchQuery}
                    onChange={(e) => {
                      setMapSearchQuery(e.target.value);
                      setMapSearchFocused(true);
                    }}
                    onFocus={() => setMapSearchFocused(true)}
                    placeholder="Search Google Maps..."
                    className="w-full text-xs bg-transparent border-none text-gray-900 dark:text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-0 select-text py-1"
                  />
                  {mapSearchQuery && (
                    <button 
                      onClick={() => {
                        setMapSearchQuery("");
                        setMapSearchFocused(false);
                      }}
                      className="text-gray-400 hover:text-gray-600 text-[10px] uppercase font-bold pr-1 shrink-0"
                    >
                      Clear
                    </button>
                  )}
                  <span className="text-[8px] font-mono font-black border border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 px-1 py-0.5 rounded text-gray-450 shrink-0 uppercase tracking-widest hidden sm:inline-block">
                    MAPS
                  </span>

                  {/* Autocomplete dropdown recommendation results card */}
                  {mapSearchFocused && (
                    <div className="absolute top-full left-0 right-0 mt-1.5 bg-white dark:bg-slate-950 border border-gray-100 dark:border-slate-800 rounded-xl shadow-2xl overflow-hidden block text-left">
                      <div className="p-1 px-2 text-[8px] font-mono font-black text-blue-500 bg-blue-50/10 dark:bg-slate-900 border-b border-gray-100 dark:border-slate-900 tracking-wider">
                        APPROVED SAFE PLACENAMES
                      </div>
                      
                      <button
                        onClick={() => {
                          setGpsLatitude(40.7570);
                          setGpsLongitude(-73.9860);
                          setMapSearchQuery("Tourist Police Substation");
                          setMapSearchFocused(false);
                          setSelectedMapMarker({
                            id: "safe-1",
                            name: "Tourist Police Substation",
                            type: "safe",
                            note: "Safe Haven Synced. Armed police guard presence active around-the-clock.",
                            distance: calculateDistanceInMeters(40.7570, -73.9860, anchorLatitude, anchorLongitude)
                          });
                          announceVoiceWarning("Recenter target track toward Tourist Police Substation secure area.");
                        }}
                        className="w-full p-2.5 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-900 flex items-center gap-1.5 border-b border-gray-100 dark:border-slate-900 cursor-pointer"
                      >
                        <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                        <div>
                          <p className="font-bold text-gray-800 dark:text-gray-200 text-[11px]">Tourist Police Substation</p>
                          <p className="text-[9px] text-gray-400">40.7570°, -73.9860° • Secure Haven</p>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setGpsLatitude(40.7588);
                          setGpsLongitude(-73.9840);
                          setMapSearchQuery("Approved Hospitality Plaza");
                          setMapSearchFocused(false);
                          setSelectedMapMarker({
                            id: "safe-2",
                            name: "Approved Hospitality Plaza",
                            type: "safe",
                            note: "Golden certified hospitality facility. Direct communications tunnel securely open.",
                            distance: calculateDistanceInMeters(40.7588, -73.9840, anchorLatitude, anchorLongitude)
                          });
                          announceVoiceWarning("Map centered on Approved Hospitality Plaza.");
                        }}
                        className="w-full p-2.5 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-900 flex items-center gap-1.5 border-b border-gray-100 dark:border-slate-900 cursor-pointer"
                      >
                        <MapPin className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                        <div>
                          <p className="font-bold text-gray-800 dark:text-gray-200 text-[11px]">Approved Hospitality Plaza</p>
                          <p className="text-[9px] text-gray-400">40.7588°, -73.9840° • Golden Safe Zone</p>
                        </div>
                      </button>

                      {/* Hazard results items */}
                      <button
                        onClick={() => {
                          setGpsLatitude(40.7562);
                          setGpsLongitude(-73.9890);
                          setMapSearchQuery("Port District Corridor");
                          setMapSearchFocused(false);
                          setSelectedMapMarker({
                            id: "haz-1",
                            name: "Red Zone: Port District",
                            type: "hazard",
                            note: "High risk active crime and pedestrian robbery reports. Safe geofence border breached.",
                            distance: calculateDistanceInMeters(40.7562, -73.9890, anchorLatitude, anchorLongitude)
                          });
                          announceVoiceWarning("Warning: Search coordinates directed to Red Zone danger territory.");
                        }}
                        className="w-full p-2.5 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                      >
                        <AlertTriangle className="h-3.5 w-3.5 text-red-500 shrink-0" />
                        <div>
                          <p className="font-bold text-gray-900 dark:text-gray-100 text-[11px]">🔴 Red Zone: Port District</p>
                          <p className="text-[9px] text-red-400 animate-pulse">Critical Danger zone • Distant: 180m</p>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* FLOATING HUD 2: Google Map Type Controller Overlays (Top Right) */}
              <div className="absolute top-4 right-4 z-30">
                <div className="bg-white/95 dark:bg-slate-900/95 shadow-xl border border-gray-200/60 dark:border-slate-800 rounded-xl p-0.5 flex gap-0.5">
                  {(["roadmap", "satellite", "terrain", "hybrid"] as const).map((typeItem) => (
                    <button
                      key={typeItem}
                      onClick={() => {
                        setMapType(typeItem);
                        announceVoiceWarning(`Switched google map display view to ${typeItem} style.`);
                      }}
                      className={`px-2.5 py-1 text-[9.5px] font-mono font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                        mapType === typeItem
                          ? "bg-blue-600 text-white shadow-md font-extrabold"
                          : "text-gray-500 dark:text-gray-300 hover:bg-gray-150 dark:hover:bg-slate-800"
                      }`}
                    >
                      {typeItem}
                    </button>
                  ))}
                </div>
              </div>

              {/* FLOATING HUD 3: Interactive Google Map Control toolbox (Bottom Right side) */}
              <div className="absolute bottom-4 right-4 z-30 flex flex-col gap-1.5 items-end">
                
                {/* Traffic Layer indicator indicator toggle */}
                <button
                  onClick={() => {
                    setShowTrafficLayer(!showTrafficLayer);
                    announceVoiceWarning(showTrafficLayer ? "Traffic overlay disabled" : "Real-time Google traffic congestion lines enabled.");
                  }}
                  className={`p-2 rounded-xl shadow-lg border cursor-pointer transition-all flex items-center gap-1.5 text-[10px] font-mono font-bold ${
                    showTrafficLayer 
                      ? "bg-emerald-500 text-white border-emerald-400" 
                      : "bg-white dark:bg-slate-900 text-gray-500 dark:text-gray-300 border-gray-200/40 dark:border-slate-805"
                  }`}
                  title="Toggle Live Traffic Flows layer"
                >
                  <Layers className="h-4 w-4" />
                  <span>Traffic</span>
                </button>

                {/* Compass Rotating Rose */}
                <button
                  onClick={() => {
                    setBearing((prev) => (prev + 45) % 360);
                    announceVoiceWarning(`Rotated compass bearing to ${bearing + 45} degrees.`);
                  }}
                  className="p-2 bg-white dark:bg-slate-900 text-gray-800 dark:text-gray-200 rounded-xl shadow-md border border-gray-200/40 dark:border-slate-800 cursor-pointer flex items-center justify-center relative hover:scale-105"
                  title="Rotate True Heading Orientation"
                >
                  <Compass className="h-5.5 w-5.5 text-blue-500 transition-transform duration-300" style={{ transform: `rotate(${bearing}deg)` }} />
                </button>

                {/* Street View Pegman Little yellow man pegman toggle */}
                <button
                  onClick={() => {
                    setIsPegmanActive(!isPegmanActive);
                    announceVoiceWarning(isPegmanActive ? "Disabled street view" : "Street View activated. Look at immediate surrounding context.");
                  }}
                  className={`p-2 rounded-xl shadow-lg border cursor-pointer transition-all flex items-center justify-center ${
                    isPegmanActive 
                      ? "bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-400/20" 
                      : "bg-white dark:bg-slate-900 text-gray-500 dark:text-gray-300 border-gray-200/40 dark:border-slate-805"
                  }`}
                  title="Interactive Pegman Street View"
                >
                  <User className="h-5 w-5 text-amber-500 shrink-0 fill-current animate-bounce" />
                </button>

                {/* Custom zoom scaling buttons (+ and -) */}
                <div className="bg-white dark:bg-slate-900 shadow-xl border border-gray-200/40 dark:border-slate-805 rounded-xl flex flex-col p-0.5 overflow-hidden">
                  <button 
                    onClick={() => {
                      if (zoomLevel < 19) {
                        setZoomLevel(prev => prev + 1);
                        announceVoiceWarning(`Zoomed google maps screen layout level ${zoomLevel + 1}.`);
                      }
                    }}
                    className="p-2 hover:bg-gray-105 dark:hover:bg-slate-800 text-gray-600 dark:text-gray-200 flex justify-center items-center cursor-pointer border-b border-gray-100 dark:border-slate-850"
                    title="Zoom Map In"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                  <button 
                    onClick={() => {
                      if (zoomLevel > 12) {
                        setZoomLevel(prev => prev - 1);
                        announceVoiceWarning(`Zoomed maps scale layout level ${zoomLevel - 1}.`);
                      }
                    }}
                    className="p-2 hover:bg-gray-105 dark:hover:bg-slate-800 text-gray-600 dark:text-gray-200 flex justify-center items-center cursor-pointer"
                    title="Zoom Map Out"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* MAP BODY MARKERS ELEMENT PLACEMENTS */}

              {/* Geofence Boundary Circle outline */}
              <div 
                className="absolute transition-all duration-300 rounded-full border-4 border-dashed border-blue-500/35 bg-blue-500/3 flex items-center justify-center pointer-events-none"
                style={{
                  left: "50%",
                  top: "50%",
                  transform: "translate(-50%, -50%)",
                  // Scale width dynamically reflecting the current zoomLevel state parameter
                  width: `${fenceRadiusMeters * (zoomLevel / 15) * 1.8}px`,
                  height: `${fenceRadiusMeters * (zoomLevel / 15) * 1.8}px`
                }}
              >
                <div className="text-[7.5px] font-mono font-black tracking-widest text-blue-500 uppercase bg-white/95 dark:bg-slate-950/95 p-1 px-1.5 rounded-lg shadow-md border border-blue-500/20 max-w-xs absolute top-[-10px] whitespace-nowrap">
                  GEOFENCE RAD: {fenceRadiusMeters}M
                </div>
              </div>

              {/* MAP MARKER: Primary Danger Corridor (hazard 1) */}
              <div 
                className="absolute text-center cursor-pointer select-none group"
                style={{
                  left: `${25 + (zoomLevel - 15) * 5}%`,
                  top: `${42 + (zoomLevel - 15) * 4}%`
                }}
                onClick={() => {
                  setSelectedMapMarker({
                    id: "haz-1",
                    name: "Red Zone: Port District Corridor",
                    type: "hazard",
                    note: "High crime pedestrian hazard. Avoid walking around docks past local sunset.",
                    distance: calculateDistanceInMeters(40.7562, -73.9890, gpsLatitude, gpsLongitude)
                  });
                  announceVoiceWarning("Warning: Hazard selected. Red Zone: Port District Corridor.");
                }}
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-75 h-7 w-7" />
                  <div className="relative h-7 w-7 rounded-xl bg-gradient-to-br from-red-650 to-rose-600 text-white flex items-center justify-center shadow-lg border-2 border-red-400 group-hover:scale-110 transition-transform">
                    <AlertOctagon className="h-4 w-4" />
                  </div>
                </div>
                <span className="mt-1 block bg-red-500/90 text-white text-[7.5px] font-mono font-black p-0.5 px-1.5 rounded shadow whitespace-nowrap">
                  RED: Port Docks
                </span>
              </div>

              {/* MAP MARKER: Market crowd pocket-picks (hazard 2) */}
              <div 
                className="absolute text-center cursor-pointer select-none group"
                style={{
                  left: `${65 - (zoomLevel - 15) * 3}%`,
                  top: `${18 + (zoomLevel - 15) * 2}%`
                }}
                onClick={() => {
                  setSelectedMapMarker({
                    id: "haz-2",
                    name: "Orange Zone: Central Market crowd",
                    type: "hazard",
                    note: "Frequent pocket picking occurrences in packed tourist crowds. Mind your belongings.",
                    distance: calculateDistanceInMeters(40.7595, -73.9820, gpsLatitude, gpsLongitude)
                  });
                  announceVoiceWarning("Crowded warning zone selected. Central Market Crowd Jams.");
                }}
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-orange-500 rounded-full animate-ping opacity-60 h-7 w-7" />
                  <div className="relative h-7 w-7 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 text-white flex items-center justify-center shadow-lg border-2 border-orange-400 group-hover:scale-110 transition-transform">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                </div>
                <span className="mt-1 block bg-amber-500 text-slate-900 text-[7.5px] font-mono font-black p-0.5 px-1.5 rounded shadow whitespace-nowrap">
                  ⚠️ Market crowd
                </span>
              </div>

              {/* DYNAMIC MAP MARKERS: Safe Zones & Police Stations */}
              {primarySafeZones.map((zone) => {
                const leftPercent = zone.leftOffset + (zoomLevel - 15) * zone.leftZoomCoef;
                const topPercent = zone.topOffset + (zoomLevel - 15) * zone.topZoomCoef;
                
                return (
                  <div 
                    key={zone.id}
                    className="absolute text-center cursor-pointer select-none group focus:outline-none"
                    style={{
                      left: `${leftPercent}%`,
                      top: `${topPercent}%`
                    }}
                    onClick={() => {
                      setSelectedMapMarker({
                        id: zone.id,
                        name: zone.name,
                        type: "safe",
                        note: zone.note,
                        distance: calculateDistanceInMeters(zone.lat, zone.lng, gpsLatitude, gpsLongitude)
                      });
                      announceVoiceWarning(`${zone.type === "police" ? "Police Precinct" : "Safe Haven"} Selected: ${zone.name}.`);
                    }}
                  >
                    <div className="h-7 w-7 rounded-xl bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center shadow-lg border-2 border-emerald-400 dark:border-emerald-300 group-hover:scale-110 transition-all">
                      {zone.type === "police" ? (
                        <ShieldCheck className="h-4.5 w-4.5 text-white animate-pulse" />
                      ) : (
                        <Globe className="h-4.5 w-4.5 text-white" />
                      )}
                    </div>
                    <span className="mt-1 block bg-emerald-700 dark:bg-emerald-600 text-[6.5px] font-mono font-black text-white p-0.5 px-1.5 rounded shadow-sm whitespace-nowrap uppercase tracking-wide">
                      {zone.type === "police" ? "🚓 Police" : "🛡️ Haven"}
                    </span>
                  </div>
                );
              })}

              {/* TRAVELER'S PROGRESS NODE PINS (Self Tracker location) */}
              <motion.div 
                className="absolute z-35 flex flex-col items-center select-none cursor-pointer"
                animate={{
                  // Position relative to map dimensions responsive coordinates
                  x: `${240 + (gpsLongitude + 73.9855) * 12000 * (zoomLevel / 15)}px`,
                  y: `${180 + (40.7580 - gpsLatitude) * 12000 * (zoomLevel / 15)}px`
                }}
                onClick={() => {
                  setSelectedMapMarker({
                    id: "user-self",
                    name: `Traveler: ${userName}`,
                    type: "safe",
                    note: `Your tracked GPS point. Active state score: ${currentScore}/100. Blood Type: ${bloodType}.`,
                    distance: 0
                  });
                  announceVoiceWarning(`Self tracking node selected. Current system safety value is ${currentScore} points.`);
                }}
                transition={{ type: "spring", stiffness: 70 }}
                title="Click to check your personal biological metrics"
              >
                <span className="relative flex h-7 w-7 justify-center items-center">
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    geoFenceBreached ? "bg-red-500" : currentScore < 60 ? "bg-amber-500" : "bg-blue-600"
                  }`}></span>
                  <div className={`relative rounded-xl h-9 w-9 text-white font-extrabold flex items-center justify-center shadow-[0_4px_15px_rgba(37,99,235,0.4)] border-2 ${
                    geoFenceBreached 
                      ? "bg-red-650 border-red-300" 
                      : currentScore < 60 
                        ? "bg-amber-500 border-amber-200" 
                        : "bg-blue-600 border-blue-400"
                  }`}>
                    {isSosTriggered ? (
                      <Siren className="h-5 w-5 animate-spin" />
                    ) : (
                      <Navigation className="h-5 w-5 transition-transform" style={{ transform: `rotate(${bearing}deg)` }} />
                    )}
                  </div>
                </span>
                <span className="mt-1 bg-slate-900 border border-slate-800 text-[8px] font-mono font-black text-white px-2 py-0.5 rounded shadow-lg whitespace-nowrap">
                  Alexis Carter (You)
                </span>
              </motion.div>

              {/* FLOATING HUD 4: INTERACTIVE STREET VIEW WINDOW POPUP */}
              <AnimatePresence>
                {isPegmanActive && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8, y: 30 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: 30 }}
                    className="absolute bottom-4 left-4 z-45 w-[260px] bg-white dark:bg-slate-950 rounded-2xl border border-gray-150 dark:border-slate-800 overflow-hidden shadow-2xl text-left"
                  >
                    <div className="bg-amber-400 p-2 text-slate-900 flex justify-between items-center">
                      <span className="text-[10px] font-black font-mono tracking-widest flex items-center gap-1">
                        🟡 GOOGLE STREET VIEW COMPANION
                      </span>
                      <button 
                        onClick={() => setIsPegmanActive(false)}
                        className="text-[10px] font-black uppercase text-slate-900 hover:text-black cursor-pointer px-1"
                      >
                        ✕
                      </button>
                    </div>

                    {/* Image street mock preview viewport */}
                    <div className="h-28 bg-gradient-to-t from-gray-200 to-gray-50 dark:from-slate-900 dark:to-slate-950 relative flex items-center justify-center">
                      {/* Grid representation with perspective lines */}
                      <svg className="absolute inset-0 w-full h-full opacity-20 stroke-current text-slate-500" strokeWidth="2">
                        <line x1="0" y1="112" x2="260" y2="112" />
                        <line x1="130" y1="112" x2="0" y2="150" />
                        <line x1="130" y1="112" x2="260" y2="150" />
                        <line x1="130" y1="112" x2="130" y2="0" />
                      </svg>
                      {/* Procedural visual simulation elements */}
                      <div className="text-center z-10 space-y-1">
                        <p className="text-[10px] font-black text-amber-500 uppercase font-mono tracking-wider animate-pulse">◆ DRIVER VIEW CAMERA ACTIVE ◆</p>
                        <p className="text-[10px] text-gray-700 dark:text-gray-300 font-bold">Broadway near West 45th St</p>
                        <p className="text-[8px] text-gray-400 font-mono">Position accuracy: ± 4m (9 Satellites)</p>
                      </div>
                    </div>
                    <div className="p-3 text-[10px] text-gray-550 dark:text-gray-300 font-mono space-y-1">
                      <div className="flex justify-between">
                        <span>Threat level standard:</span>
                        <span className="text-emerald-500 font-bold font-sans uppercase">SAFE ZONE</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pavement type index:</span>
                        <span className="text-gray-700 dark:text-gray-200 font-bold">Urban Paved Highway</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* FLOATING HUD 5: SELECT MARKER INFO WINDOW OVERLAY */}
              <AnimatePresence>
                {selectedMapMarker && (
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    className="absolute bottom-24 left-1/2 -translate-x-1/2 z-40 max-w-[280px] w-full bg-white/95 dark:bg-slate-950/95 backdrop-blur-md p-3.5 rounded-2xl border border-gray-150 dark:border-slate-800 shadow-2xl text-left space-y-2.5"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <span className={`text-[8px] font-mono font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                          selectedMapMarker.type === "hazard" ? "bg-red-500/10 text-red-500" : "bg-emerald-500/10 text-emerald-500"
                        }`}>
                          {selectedMapMarker.type === "hazard" ? "Crime Danger Block" : "Clear Safe Haven"}
                        </span>
                        <h4 className="text-xs font-black text-gray-900 dark:text-white mt-1.5 font-display">{selectedMapMarker.name}</h4>
                      </div>
                      <button 
                        onClick={() => setSelectedMapMarker(null)} 
                        className="text-gray-400 hover:text-gray-600 dark:hover:text-white text-[10px] uppercase font-bold pr-1 cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>

                    <p className="text-[10px] text-gray-500 dark:text-gray-300 leading-relaxed font-mono">
                      {selectedMapMarker.note}
                    </p>

                    <div className="pt-2 border-t border-gray-100 dark:border-slate-900 flex justify-between items-center text-[9px] font-mono text-gray-400">
                      <span>Proximity distance:</span>
                      <span className="font-extrabold text-blue-500">{selectedMapMarker.distance} meters away</span>
                    </div>

                    {/* Quick navigation router controls inside marker window */}
                    {selectedMapMarker.type === "safe" && selectedMapMarker.id !== "user-self" && (
                      <button
                        onClick={() => {
                          setGpsLatitude(selectedMapMarker.id === "safe-1" ? 40.7570 : 40.7588);
                          setGpsLongitude(selectedMapMarker.id === "safe-1" ? -73.9860 : -73.9840);
                          announceVoiceWarning(`Recalibrating walking route toward ${selectedMapMarker.name}. Stay on sidewalk channels.`);
                        }}
                        className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[9px] font-black uppercase tracking-wider cursor-pointer text-center"
                      >
                        Navigate Safest Route Here
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

            </div>

            {/* Quick Manual Nudge Joystick controls and telemetry display log */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-gray-150 dark:border-slate-800/80">
              
              {/* Coordinates readouts */}
              <div className="flex flex-col justify-center space-y-1 text-xs text-left font-mono text-gray-500 dark:text-gray-400">
                <div className="flex justify-between">
                  <span>GPS Lat/Lng Coordinates:</span>
                  <span className="font-bold text-gray-900 dark:text-gray-200">
                    {gpsLatitude.toFixed(6)}° N, {gpsLongitude.toFixed(6)}° W
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Satellites Signal:</span>
                  <span className="text-emerald-500 font-bold flex items-center gap-1">
                    🟢 {connectedSatellites} Connected
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Geofence distance anchor:</span>
                  <span className={`font-bold ${geoFenceBreached ? "text-red-500 animate-pulse" : "text-gray-650 dark:text-gray-200"}`}>
                    {distanceFromGeofenceAnchor} meters {geoFenceBreached ? "(OUT)" : "(SAFE)"}
                  </span>
                </div>
              </div>

              {/* Joystick Manual controls */}
              <div className="flex flex-col items-center justify-center space-y-2">
                <span className="text-[9px] font-mono font-black text-gray-450 uppercase uppercase">Fine-Tune Coordinate Position (Joystick)</span>
                <div className="flex gap-1.5">
                  <button 
                    onClick={() => handleManualNudge("W")} 
                    className="p-1 px-3 bg-gray-50 hover:bg-gray-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-gray-200/20 dark:border-slate-800 rounded-lg text-[10px] font-extrabold cursor-pointer"
                  >
                    ◀ West
                  </button>
                  <div className="flex flex-col gap-1.5">
                    <button 
                      onClick={() => handleManualNudge("N")} 
                      className="p-1 px-3 bg-gray-50 hover:bg-gray-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-gray-200/20 dark:border-slate-800 rounded-lg text-[10px] font-extrabold cursor-pointer"
                    >
                      ▲ North
                    </button>
                    <button 
                      onClick={() => handleManualNudge("S")} 
                      className="p-1 px-3 bg-gray-50 hover:bg-gray-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-gray-200/20 dark:border-slate-800 rounded-lg text-[10px] font-extrabold cursor-pointer"
                    >
                      ▼ South
                    </button>
                  </div>
                  <button 
                    onClick={() => handleManualNudge("E")} 
                    className="p-1 px-3 bg-gray-50 hover:bg-gray-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-gray-200/20 dark:border-slate-800 rounded-lg text-[10px] font-extrabold cursor-pointer"
                  >
                    East ▶
                  </button>
                </div>
              </div>

            </div>

          </div>

          {/* NEARBY POLICE STATIONS & SECURE HAVENS LIST */}
          <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-md p-6 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 shadow-md text-left space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-150 dark:border-slate-800/80">
              <div className="space-y-0.5">
                <span className="text-[10px] font-black font-mono tracking-widest text-[#2563eb] dark:text-[#3b82f6] uppercase flex items-center gap-1.5">
                  <ShieldCheck className="h-4.5 w-4.5" /> NEARBY LAW ENFORCEMENT & SECURE HAVENS
                </span>
                <p className="text-[10.5px] text-gray-500 dark:text-gray-400">Dynamic dispatch stations closest to your tracked coordinates</p>
              </div>

              {/* Filters selector */}
              <div className="flex gap-1 bg-gray-100 dark:bg-slate-900/60 p-0.5 rounded-xl border border-gray-200/10 dark:border-slate-800 shrink-0">
                <button
                  onClick={() => setSafeZoneFilter("all")}
                  className={`px-2 py-1 text-[9px] font-mono font-black uppercase rounded-lg cursor-pointer transition-all ${
                    safeZoneFilter === "all"
                      ? "bg-blue-650 text-white shadow-sm font-extrabold"
                      : "text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200"
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setSafeZoneFilter("police")}
                  className={`px-2 py-1 text-[9px] font-mono font-black uppercase rounded-lg cursor-pointer transition-all ${
                    safeZoneFilter === "police"
                      ? "bg-blue-650 text-white shadow-sm font-extrabold"
                      : "text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200"
                  }`}
                >
                  Precincts
                </button>
                <button
                  onClick={() => setSafeZoneFilter("close")}
                  className={`px-2 py-1 text-[9px] font-mono font-black uppercase rounded-lg cursor-pointer transition-all ${
                    safeZoneFilter === "close"
                      ? "bg-blue-650 text-white shadow-sm font-extrabold"
                      : "text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200"
                  }`}
                >
                  &lt; 250m
                </button>
              </div>
            </div>

            {/* Stations list mapping */}
            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {primarySafeZones
                .map((zone) => {
                  const distance = calculateDistanceInMeters(gpsLatitude, gpsLongitude, zone.lat, zone.lng);
                  return { ...zone, distance };
                })
                .filter((zone) => {
                  if (safeZoneFilter === "police") return zone.type === "police";
                  if (safeZoneFilter === "close") return zone.distance <= 250;
                  return true;
                })
                .sort((a, b) => a.distance - b.distance) // closest first
                .map((zone) => {
                  const isSelectedOnMap = selectedMapMarker?.id === zone.id;
                  
                  return (
                    <div 
                      key={zone.id}
                      className={`g-panel-secure p-3.5 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 text-left ${
                        isSelectedOnMap 
                          ? "bg-emerald-500/5 dark:bg-emerald-950/20 border-emerald-500/30 shadow-md shadow-emerald-500/5" 
                          : "bg-gray-50/70 dark:bg-slate-900/40 border-gray-150 dark:border-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-900/60"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {/* Status Icon Indicator */}
                        <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                          zone.type === "police" 
                            ? "bg-blue-600/10 text-[#2563eb] dark:text-[#3b82f6]" 
                            : "bg-emerald-600/10 text-emerald-500"
                        }`}>
                          {zone.type === "police" ? (
                            <Shield className="h-5 w-5" />
                          ) : (
                            <Globe className="h-5 w-5" />
                          )}
                        </div>

                        {/* Station descriptions */}
                        <div className="space-y-1 block max-w-sm">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h5 className="text-xs font-black text-gray-900 dark:text-gray-100 font-display">{zone.name}</h5>
                            <span className={`text-[8.5px] font-mono font-black uppercase tracking-widest px-1.5 py-0.5 rounded leading-none ${
                              zone.type === "police" 
                                ? "bg-blue-500/10 text-[#2563eb] dark:text-[#3b82f6]" 
                                : "bg-emerald-500/10 text-emerald-500"
                            }`}>
                              {zone.type === "police" ? "Precinct" : "Haven"}
                            </span>
                            <span className="text-[9.5px] font-extrabold text-blue-600 dark:text-blue-400 font-mono">
                              • {zone.distance}m away
                            </span>
                          </div>

                          <p className="text-[9.5px] text-gray-400 font-mono">{zone.address}</p>
                          <p className="text-[10px] text-gray-650 dark:text-gray-300 leading-relaxed font-sans mt-1">
                            {zone.note}
                          </p>

                          <div className="flex items-center gap-3 pt-1.5 text-[9px] font-mono text-gray-450 border-t border-gray-100 dark:border-slate-800/60 mt-1">
                            <span className="text-emerald-500 font-extrabold flex items-center gap-1">
                              🟢 {zone.status}
                            </span>
                            <span>• Tel: {zone.phone}</span>
                          </div>
                        </div>
                      </div>

                      {/* Interactive Trigger Actions */}
                      <div className="flex md:flex-col gap-1.5 shrink-0 self-end md:self-center w-full md:w-auto">
                        <button
                          onClick={() => {
                            // Focus on map search query and open the description popup
                            setGpsLatitude(zone.lat);
                            setGpsLongitude(zone.lng);
                            setSelectedMapMarker({
                              id: zone.id,
                              name: zone.name,
                              type: "safe",
                              note: zone.note,
                              distance: zone.distance
                            });
                            announceVoiceWarning(`Centering coordinates on ${zone.name}. Location index: ${zone.lat.toFixed(4)}, ${zone.lng.toFixed(4)}.`);
                          }}
                          className={`flex-1 md:w-28 py-1.5 text-center text-[9.5px] font-black uppercase tracking-wider rounded-lg border transition-all cursor-pointer ${
                            isSelectedOnMap 
                              ? "bg-emerald-600 border-emerald-500 text-white" 
                              : "bg-white dark:bg-slate-900 hover:bg-gray-100 dark:hover:bg-slate-850 text-gray-700 dark:text-gray-250 border-gray-200/40 dark:border-slate-800"
                          }`}
                        >
                          Find on Map
                        </button>
                        <button
                          onClick={() => {
                            // Route safe coordinates toward the police station and restore safety scoring
                            // Set coordinates close to the police station
                            setGpsLatitude(zone.lat + 0.0003); // slightly offset to simulate standard dynamic walk position
                            setGpsLongitude(zone.lng - 0.0004);
                            setSelectedMapMarker({
                              id: zone.id,
                              name: zone.name,
                              type: "safe",
                              note: `Bypassing Red Zone risk grid. Safe path established. Protected desk 15 meters away.`,
                              distance: 15
                            });
                            announceVoiceWarning(`Re-routing activated. Navigating safely around hazard blocks. Directional corridor established to ${zone.name}.`);
                          }}
                          className="flex-1 md:w-28 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-center text-[9.5px] font-black uppercase tracking-wider rounded-lg cursor-pointer"
                        >
                          Safe Route
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Voice Command Assistant Micro UI 🎤 */}
          <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-md p-5 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl shrink-0 ${isListening ? "bg-red-500 animate-pulse text-white" : "bg-blue-500/10 text-blue-500"}`}>
                  <Mic className="h-5 w-5" />
                </div>
                <div className="text-left">
                  <h4 className="text-xs font-black font-mono tracking-widest text-gray-400 uppercase">Voice Copilot Command System 🎤</h4>
                  <p className="text-[10px] text-gray-500">Enable hands-free tracking prompts or alarm overrides</p>
                </div>
              </div>

              {/* mic button trigger */}
              <button
                onClick={handleMicrophoneVoiceInput}
                className={`py-2 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                  isListening 
                    ? "bg-red-500 hover:bg-red-600 text-white animate-pulse" 
                    : "bg-blue-600 hover:bg-blue-700 text-white"
                }`}
                id="voice-command-mic-trigger"
              >
                <span>{isListening ? "Recording Voice..." : "Press to Speak"}</span>
              </button>
            </div>

            {/* Simulated captures text query displays */}
            {(voiceQuery || speechError) && (
              <div className="mt-3 p-3 rounded-2xl bg-gray-50 dark:bg-slate-900/60 border border-gray-200/10 dark:border-slate-800 text-xs font-mono space-y-1 block text-left">
                {voiceQuery && (
                  <p className="text-gray-800 dark:text-gray-200">
                    <span className="text-blue-500 font-bold text-[10px] uppercase block tracking-widest">Captured phrase:</span>
                    "{voiceQuery}"
                  </p>
                )}
                {speechError && (
                  <p className="text-red-500">
                    ⚠️ {speechError} Running fallback mock command line.
                  </p>
                )}
                <div className="pt-2 border-t border-gray-200/20 flex gap-2 flex-wrap">
                  <button 
                    onClick={() => processVocalQuery("Trigger SOS Panic Alert")}
                    className="bg-red-550/10 text-red-500 hover:bg-red-500/10 text-[9px] font-bold px-2 py-0.5 rounded border border-red-550/20 cursor-pointer"
                  >
                    "SOS Emergency"
                  </button>
                  <button 
                    onClick={() => processVocalQuery("Configure 250m Geofence")}
                    className="bg-blue-550/10 text-blue-500 hover:bg-blue-500/10 text-[9px] font-bold px-2 py-0.5 rounded border border-blue-550/20 cursor-pointer"
                  >
                    "Set 250m Geofence"
                  </button>
                  <button 
                    onClick={() => processVocalQuery("Silence active alarms")}
                    className="bg-emerald-550/10 text-emerald-500 hover:bg-emerald-550/10 text-[9px] font-bold px-2 py-0.5 rounded border border-emerald-550/20 cursor-pointer"
                  >
                    "Silence Alarms"
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

        {/* RIGHT COLUMN: Digital ID Pass + SOS Controls (4 cols) */}
        <div className="lg:col-span-4 flex flex-col justify-between space-y-6">
          
          {/* DIGITAL TOURIST ID CARD PASS */}
          <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-md p-6 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 shadow-md flex flex-col justify-between space-y-5">
            <div className="flex justify-between items-center pb-2.5 border-b border-gray-150 dark:border-slate-800/80">
              <span className="text-[10px] font-black font-mono tracking-widest text-emerald-500 uppercase flex items-center gap-1">
                <Award className="h-4 w-4" /> DIGITAL AUTHORIZATION PASS
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500 text-[8px] font-mono font-bold tracking-widest">
                VERIFIED
              </span>
            </div>

            {/* Golden Passport Badge Widget */}
            <div className="p-4 bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl relative overflow-hidden shadow-lg border border-indigo-500/20 text-left space-y-4">
              
              {/* Chip design detail */}
              <div className="flex justify-between items-start">
                <div className="h-8 w-11 rounded-md bg-gradient-to-r from-amber-400 to-amber-200 border border-amber-500/25 relative overflow-hidden flex items-center justify-center">
                  <div className="absolute inset-0 grid grid-cols-4 opacity-40">
                    {Array.from({ length: 4 }).map((_, i) => <div key={i} className="border-r border-gray-900" />)}
                  </div>
                </div>
                <div className="text-right text-[8px] font-mono leading-none tracking-widest text-indigo-300">
                  <p className="font-extrabold uppercase">Sovereign clearance Pass</p>
                  <p className="text-[7px] text-gray-400">EXP: 08-2028</p>
                </div>
              </div>

              {/* Personal passport specs name, country, clearance status */}
              <div className="space-y-1 block">
                <span className="text-[9px] uppercase font-mono text-gray-400 tracking-wider">PRIMARY VISITOR</span>
                <h4 className="text-base font-black tracking-wide font-sans">{userName}</h4>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[9.5px] font-mono text-gray-300">
                <div>
                  <span className="text-[7.5px] text-gray-500 uppercase block">VISA STAMP</span>
                  <span className="font-bold text-white uppercase">{userPlan}</span>
                </div>
                <div>
                  <span className="text-[7.5px] text-gray-500 uppercase block">PASSPORT INDEX</span>
                  <span className="font-extrabold text-blue-400">{passportId}</span>
                </div>
              </div>

              {/* Dynamic generated Barcode scan line */}
              <div className="pt-2 border-t border-white/10 flex justify-between items-center">
                <div className="font-mono text-[8px] tracking-widest text-white/50 block"> // TOUR-SEC-9482X // </div>
                {/* Micro thumbnail scan link to show full popup clearance card */}
                <button
                  onClick={() => setShowQRModal(true)}
                  className="p-1 px-2.5 bg-indigo-500/25 hover:bg-indigo-500/50 rounded-lg text-[9px] font-bold text-indigo-300 border border-indigo-400/20 cursor-pointer flex items-center gap-1 shrink-0"
                >
                  <QrCode className="h-3 w-3 text-indigo-300" /> Toggle pass QR
                </button>
              </div>

            </div>

            {/* Quick interactive parameters indicator safety index scale */}
            <div className="p-4 bg-gray-50/50 dark:bg-slate-900/40 rounded-2xl border border-gray-200/20 dark:border-slate-800 bg-grid-pattern space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-gray-500 dark:text-gray-450 font-mono tracking-wider">SAFETY CRITICALITY VALUE</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                  currentScore > 80 ? "bg-emerald-500/10 text-emerald-500" : currentScore > 60 ? "bg-amber-500/10 text-amber-500" : "bg-red-500/10 text-red-500 animate-pulse"
                }`}>
                  {currentScore}/100 SCORE
                </span>
              </div>

              {/* Slider meter displays */}
              <div className="relative">
                <div className="w-full bg-gray-200 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-700 ${
                      currentScore > 80 ? "bg-emerald-500" : currentScore > 60 ? "bg-amber-500" : "bg-red-500 animate-pulse"
                    }`}
                    style={{ width: `${currentScore}%` }}
                  />
                </div>
                <div className="absolute top-4 left-0 right-0 flex justify-between text-[8px] text-gray-400 font-mono">
                  <span>DANGER</span>
                  <span>SAFETY ZONE</span>
                </div>
              </div>

              {/* Dynamic Voice alert text message visualizer */}
              <div className="pt-2.5 border-t border-gray-150 dark:border-slate-800/80 text-left">
                <span className="text-[9px] font-mono font-extrabold text-blue-500 uppercase flex items-center gap-1">
                  <Volume2 className="h-3 w-3 animate-pulse" /> Live AI Vocal Warnings Tracker
                </span>
                <p className="text-[11px] text-gray-650 dark:text-gray-300 font-mono mt-1 font-semibold italic bg-blue-500/5 p-2 rounded-xl border border-blue-500/10">
                  "{systemVoiceWarningText}"
                </p>
              </div>

            </div>

          </div>

          {/* ACTIVE SOS PANIC BEACON CONTROL PANEL */}
          <div className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-md p-6 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 shadow-md text-center space-y-4">
            
            <div className="flex justify-between items-center text-xs pb-1 border-b border-gray-100 dark:border-slate-850">
              <span className="font-extrabold font-mono text-red-500 tracking-wider">PANIC CENTER MATRIX</span>
              <span className="h-2 w-2 rounded-full bg-red-500 animate-ping" />
            </div>

            {/* MAIN DYNAMIC CRISIS TRIGGER BUTTON */}
            <div className="py-2 flex items-center justify-center relative">
              
              <AnimatePresence>
                {sosCountdown !== null ? (
                  /* Countdown overlay block */
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="h-32 w-32 rounded-full bg-red-650 flex flex-col justify-center items-center text-white border-4 border-red-400 cursor-pointer shadow-lg animate-pulse"
                    onClick={resetSOSSystems}
                  >
                    <span className="text-[10px] font-mono font-black tracking-widest">ACCIDENTAL?</span>
                    <span className="text-4xl font-extrabold font-display leading-none mt-1">{sosCountdown}</span>
                    <span className="text-[9px] font-black uppercase mt-1">CANCEL SECS</span>
                  </motion.div>
                ) : isSosTriggered ? (
                  /* Triggered Sirens Active pass button */
                  <motion.div
                    initial={{ scale: 0.8 }}
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ repeat: Infinity, duration: 1.2 }}
                    className="h-32 w-32 rounded-full bg-gradient-to-tr from-red-650 to-rose-600 flex flex-col justify-center items-center text-white border-4 border-white cursor-pointer shadow-[0_0_35px_rgba(239,68,68,0.5)]"
                    onClick={resetSOSSystems}
                    title="Click to Silencing Alarms override"
                  >
                    <Siren className="h-8 w-8 text-white animate-spin mt-1" />
                    <span className="text-[9.5px] font-black uppercase mt-1 tracking-widest">SILENCE ALARM</span>
                  </motion.div>
                ) : (
                  /* Standard Idle SOS Trigger button container */
                  <motion.button
                    whileHover={{ scale: 1.06 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={triggerActiveSOSCountdown}
                    className="h-32 w-32 rounded-full bg-gradient-to-tr from-red-600 to-rose-500 flex flex-col justify-center items-center text-white border-4 border-red-500 hover:border-red-400 cursor-pointer shadow-lg shadow-red-500/20 active:scale-97 text-center group"
                    id="emergency-sos-activate-trigger"
                  >
                    <AlertTriangle className="h-8 w-8 text-white group-hover:scale-110 transition-transform" />
                    <span className="text-base font-extrabold font-display tracking-widest leading-none mt-1">S.O.S</span>
                    <span className="text-[8px] font-mono font-bold tracking-wider mt-0.5 uppercase opacity-90 block">HOLD FOR PANIC</span>
                  </motion.button>
                )}
              </AnimatePresence>

            </div>

            {/* Warning sound settings indicators */}
            <div className="flex justify-between items-center px-4 py-2 bg-gray-50 dark:bg-slate-900/40 rounded-xl border border-gray-200/20 border text-xs">
              <span className="font-bold text-gray-500 dark:text-gray-450 flex items-center gap-1 text-[11px] font-mono">
                {isSirenActive ? "🔊 Siren Audio Generator Synced" : "🔇 Speaker sirens silent"}
              </span>
              <button
                onClick={() => isSirenActive ? stopSirenOscillator() : startSirenOscillator()}
                className={`px-2.5 py-1 text-[10px] font-black rounded cursor-pointer transition-colors ${
                  isSirenActive 
                    ? "bg-red-550/10 text-red-500 hover:bg-red-550/20" 
                    : "bg-blue-550/10 text-blue-500 hover:bg-blue-550/20"
                }`}
              >
                {isSirenActive ? "Stop Test" : "Trigger test"}
              </button>
            </div>

            {/* Panic event Dispatch log outputs */}
            <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-slate-900/60 border border-gray-200/10 dark:border-slate-800 text-[10px] font-mono text-left space-y-1 max-h-[140px] overflow-y-auto">
              <span className="text-gray-400 font-bold block border-b border-gray-200/20 pb-1 mb-1.5 uppercase tracking-widest">SOS BEACON SATELLITE TRANSACTION LOG</span>
              {sosLogs.length === 0 ? (
                <p className="text-gray-400 italic text-center">No active panic event logged in security node.</p>
              ) : (
                sosLogs.map((log, idx) => (
                  <p key={idx} className={log.includes("DISPATCH") || log.includes("ALERT") ? "text-red-500 font-extrabold" : "text-gray-500"}>
                    {log}
                  </p>
                ))
              )}
            </div>

          </div>

        </div>

      </div>

      {/* DETAILED FEATURES OVERVIEW DIALOG POPUP MODAL (EXPANDED QR CODE PASSPORT) */}
      <AnimatePresence>
        {showQRModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 text-center cursor-pointer"
            onClick={() => setShowQRModal(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 15 }}
              className="bg-white dark:bg-slate-950 p-6 rounded-3xl border border-gray-100 dark:border-gray-900 max-w-sm w-full text-center space-y-5 cursor-default shadow-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center pb-3 border-b border-gray-150 dark:border-slate-850">
                <h4 className="text-sm font-black font-mono tracking-widest text-emerald-500 uppercase uppercase">Tourist Clearance ID Token</h4>
                <button 
                  onClick={() => setShowQRModal(false)}
                  className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Dynamic SVG QR code block */}
              <div className="flex flex-col items-center justify-center space-y-3.5">
                <div className="p-3 bg-white border-2 border-indigo-500/10 rounded-2xl shadow-md">
                  {/* Clean SVG representations of QR mapping pixels */}
                  <svg className="h-44 w-44 text-gray-900" viewBox="0 0 100 100">
                    {/* Corners anchors details */}
                    <rect x="0" y="0" width="22" height="22" fill="currentColor" rx="2" />
                    <rect x="3" y="3" width="16" height="16" fill="white" rx="1.5" />
                    <rect x="6" y="6" width="10" height="10" fill="currentColor" rx="1" />

                    <rect x="78" y="0" width="22" height="22" fill="currentColor" rx="2" />
                    <rect x="81" y="3" width="16" height="16" fill="white" rx="1.5" />
                    <rect x="84" y="6" width="10" height="10" fill="currentColor" rx="1" />

                    <rect x="0" y="78" width="22" height="22" fill="currentColor" rx="2" />
                    <rect x="3" y="81" width="16" height="16" fill="white" rx="1.5" />
                    <rect x="6" y="84" width="10" height="10" fill="currentColor" rx="1" />

                    {/* QR Code detailed data grids simulation */}
                    <g fill="currentColor">
                      {/* Random procedural structural clusters mapping */}
                      <rect x="28" y="4" width="6" height="6" />
                      <rect x="40" y="0" width="12" height="4" />
                      <rect x="60" y="6" width="6" height="12" />
                      <rect x="34" y="14" width="18" height="6" />
                      
                      <rect x="4" y="28" width="18" height="6" />
                      <rect x="12" y="38" width="6" height="14" />
                      <rect x="24" y="24" width="14" height="14" />
                      <rect x="42" y="28" width="8" height="8" />
                      <rect x="58" y="24" width="14" height="6" />
                      <rect x="78" y="28" width="18" height="8" />

                      <rect x="6" y="62" width="12" height="6" />
                      <rect x="28" y="48" width="14" height="14" />
                      <rect x="48" y="44" width="22" height="6" />
                      <rect x="74" y="42" width="6" height="12" />
                      <rect x="86" y="48" width="12" height="6" />

                      <rect x="28" y="68" width="12" height="12" />
                      <rect x="46" y="60" width="18" height="22" />
                      <rect x="68" y="68" width="8" height="14" />
                      <rect x="82" y="64" width="12" height="12" />

                      <rect x="4" y="58" width="6" height="12" />
                      <rect x="8" y="52" width="12" height="4" />
                      <rect x="18" y="72" width="4" height="4" />
                      <rect x="14" y="66" width="6" height="6" />
                      <rect x="84" y="86" width="12" height="12" />
                    </g>
                  </svg>
                </div>
                
                <div className="text-xs text-center space-y-1 block">
                  <span className="font-extrabold text-gray-800 dark:text-gray-150 block">{userName}'s Secure Identity QR Code</span>
                  <p className="text-[10px] text-gray-400 font-mono">ID Hash Code: {passportId}-SEC-CRYPT</p>
                </div>
              </div>

              {/* Medical Information card details easily readable */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-slate-900 border border-gray-150 dark:border-slate-800 text-xs text-left space-y-2 font-mono">
                <span className="font-black text-blue-500 text-[10px] block uppercase tracking-wider">EMERGENCY MEDICAL PARAMETERS</span>
                <div className="flex justify-between">
                  <span className="text-gray-400">Blood Type Group:</span>
                  <span className="font-bold text-gray-900 dark:text-white uppercase">{bloodType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Severe Allergies:</span>
                  <span className="font-bold text-red-500 font-sans">{allergies}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Coverage Level:</span>
                  <span className="font-extrabold text-emerald-500 uppercase">{userPlan}</span>
                </div>
              </div>

              <div className="bg-amber-500/5 p-3 rounded-xl border border-amber-500/15 text-[10px] text-amber-700 dark:text-amber-400 leading-normal block text-left">
                Scan displays secure encrypted parameters using active Bluetooth/Beacon, bypassing cellular internet nodes in deep subway lines.
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
