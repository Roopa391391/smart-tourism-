import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Sparkles, MapPin, MessageSquare, AlertTriangle, Users, Compass, Globe, CheckCircle2, ChevronRight, Activity, Zap, HardDrive, PhoneCall, CreditCard, Lock, Check, X, ShieldCheck } from "lucide-react";

interface LandingPageProps {
  onNavigate: (tab: string) => void;
  isDarkMode: boolean;
}

export default function LandingPage({ onNavigate, isDarkMode }: LandingPageProps) {
  const [activePromoCard, setActivePromoCard] = useState<number | null>(null);
  
  // Dynamic User Plan State
  const [currentPlan, setCurrentPlan] = useState<string>(() => localStorage.getItem("userPlan") || "Voyager Solo");
  
  // Checkout Modal State
  const [checkoutPlan, setCheckoutPlan] = useState<any | null>(null);
  const [paymentStep, setPaymentStep] = useState<"form" | "processing" | "success">("form");
  const [processingStatus, setProcessingStatus] = useState("Encrypting secure session...");
  
  // Form input state
  const [cardNumber, setCardNumber] = useState("4111 4821 9104 3822");
  const [cardExpiry, setCardExpiry] = useState("12/28");
  const [cardCVC, setCardCVC] = useState("402");
  const [cardHolderName, setCardHolderName] = useState(() => localStorage.getItem("traveler_name") || "Alexis Carter");
  const [saveSuccessNotify, setSaveSuccessNotify] = useState<string | null>(null);

  // Sync state changes with other pages/header via window event storage
  const updateActivePlan = (planName: string) => {
    localStorage.setItem("userPlan", planName);
    setCurrentPlan(planName);
    // Dispatch general storage event so Profile and header reload
    window.dispatchEvent(new Event("storage"));
  };

  const stats = [
    { label: "Tourists Protected", value: "482,914", change: "+14% this month", icon: Users, color: "text-blue-500" },
    { label: "Incidents Diverted", value: "11,842", change: "99.8% resolution score", icon: Shield, color: "text-emerald-500" },
    { label: "Avg. Assistance Speed", value: "1.4s", change: "Real-time satellite link", icon: Zap, color: "text-amber-500" },
    { label: "Sovereign Countries Shielded", value: "142", change: "Interconnected police sync", icon: Globe, color: "text-purple-500" }
  ];

  const features = [
    {
      title: "AI Risk Prediction Engine",
      description: "Applies real-time crime forecasting, natural-hazard detection, crowd-risk models, and historical safety telemetry to flag potential hazards before they develop.",
      icon: AlertTriangle,
      color: "bg-amber-500/10 text-amber-500"
    },
    {
      title: "Conversational Copilot AI",
      description: "Your 24/7 localized safety companion. Speaks 44 languages with native context matching, offline support backup, and instantaneous localized authority matching.",
      icon: MessageSquare,
      color: "bg-blue-500/10 text-blue-500"
    },
    {
      title: "Dynamic Smart Score Dashboard",
      description: "Generates localized safety safety ratings from real-time crowd densities, neighborhood records, climate warnings, and pedestrian transit logs.",
      icon: Activity,
      color: "bg-emerald-500/10 text-emerald-500"
    },
    {
      title: "Autonomous Instant SOS",
      description: "One-click action locks your GPS coordinates, launches incident audio classification feeds, raises satellite warning banners, and triggers emergency authorities.",
      icon: Shield,
      color: "bg-coral-500/10 text-orange-500"
    }
  ];

  const packages = [
    {
      name: "Voyager Solo",
      price: "$0",
      period: "Forever Free",
      features: [
        "24/7 AI conversational tourist assistant",
        "Standard safety score lookup",
        "Public local authority list",
        "Manual client-side SOS logs"
      ],
      cta: "Current Free License",
      active: false
    },
    {
      name: "Voyager Elite Guardian",
      price: "$9",
      period: "per month",
      features: [
        "Priority Gemini-powered hazard forecast",
        "Active Live Guardian Track syncing",
        "One-Click Satellite Authority dispatch",
        "High-definition image risk assessment",
        "Offline mapping sync cache"
      ],
      cta: "Activate Tourism Elite",
      active: true
    },
    {
      name: "State/Diplomat Enterprise",
      price: "Custom",
      period: "Tailored quota",
      features: [
        "Government tourism department console",
        "Automated regional geo-fence broadcast",
        "API endpoint access for travel operators",
        "Real-time cluster hotspot mapping",
        "Dedicated dispatcher support lines"
      ],
      cta: "Enquire Now",
      active: false
    }
  ];

  return (
    <div className="space-y-16 py-6 font-sans">
      {/* Hero Section */}
      <section className="relative grid grid-cols-1 gap-12 lg:grid-cols-12 items-center">
        <div className="lg:col-span-7 space-y-7 text-left">
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2.5 px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-bold tracking-wider font-mono uppercase"
          >
            <Sparkles className="h-4 w-4 animate-pulse" /> Autonomous Smart Security Approved
          </motion.div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-display text-gray-900 dark:text-white leading-[1.1]">
            Empowering Every Journey with <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-400 to-emerald-400">Autonomous Security</span>
          </h1>
          
          <p className="text-base sm:text-lg text-gray-600 dark:text-gray-300 max-w-2xl leading-relaxed">
            The next generation smart safety system. Empowering global travelers with predictive hazard forecast matrices, immediate multilingual SOS, and satellite local responder coordination squads.
          </p>

          <div className="flex flex-wrap gap-4 pt-2">
            <button
              onClick={() => onNavigate("reporting")}
              className="px-6 py-4 rounded-2xl font-extrabold bg-gradient-to-r from-red-650 to-orange-500 text-white hover:shadow-xl hover:shadow-red-500/35 active:scale-97 transition-all flex items-center gap-2 text-sm shadow-md cursor-pointer border border-transparent"
              id="landing-sos-cta"
            >
              <Shield className="h-5 w-5 animate-pulse" /> Launch Crisis Monitor
            </button>
            <button
              onClick={() => onNavigate("assistant")}
              className="px-6 py-4 rounded-2xl font-bold bg-white hover:bg-gray-100 dark:bg-slate-900 dark:hover:bg-slate-800 text-gray-800 dark:text-white border border-gray-250 dark:border-slate-800 shadow-sm active:scale-98 transition-all flex items-center gap-2 text-sm cursor-pointer"
              id="landing-chat-cta"
            >
              <MessageSquare className="h-5 w-5 text-blue-500" /> Consult Safety AI Assistant
            </button>
            <button
              onClick={() => onNavigate("dashboard")}
              className="px-6 py-4 rounded-2xl font-bold bg-gray-100 hover:bg-gray-200 dark:bg-slate-850 dark:hover:bg-slate-800 text-gray-700 dark:text-gray-300 active:scale-98 transition-all flex items-center gap-2 text-sm cursor-pointer border border-transparent"
              id="landing-dashboard-cta"
            >
              <Compass className="h-5 w-5 text-emerald-500" /> Intel Map Dashboard
            </button>
          </div>

          <div className="flex items-center gap-6 pt-4 text-xs text-gray-500 dark:text-gray-400 font-mono">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
              <span>4,001 Dispatch Areas Active</span>
            </div>
            <div>•</div>
            <div className="flex items-center gap-1">
              <Activity className="h-3.5 w-3.5 text-blue-500" />
              <span>Response Lag Time: 1.2s</span>
            </div>
          </div>
        </div>

        {/* Live Tracking Visual Map Simulation */}
        <div className="lg:col-span-5 relative">
          <div className="absolute -inset-1.5 rounded-[2.2rem] bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 opacity-20 blur-xl"></div>
          <div className="relative rounded-3xl border border-gray-200/60 dark:border-slate-800 bg-white/70 dark:bg-slate-950/75 p-5 backdrop-blur-md shadow-2xl overflow-hidden min-h-[380px]">
            <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-slate-850">
              <div className="flex items-center gap-2">
                <span className="block h-2.5 w-2.5 rounded-full bg-blue-600 animate-pulse"></span>
                <span className="text-sm font-bold font-display text-gray-805 dark:text-white">Global Tourism Tracker</span>
              </div>
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-blue-500/10 text-blue-600 dark:text-blue-400 uppercase tracking-widest font-bold border border-blue-500/20">Active GPS Stream</span>
            </div>

            {/* Custom SVG World Map Graphic with glowing points */}
            <div className="h-[260px] w-full flex items-center justify-center relative mt-3 select-none">
              <svg className="w-full h-full text-gray-200 dark:text-gray-800" viewBox="0 0 1000 500" fill="currentColor">
                {/* Simulated simplified world continents */}
                {/* North America */}
                <path d="M150,120 Q180,80 250,110 T300,180 T260,260 T140,240 T150,120" />
                {/* South America */}
                <path d="M260,260 Q320,280 280,380 T240,460 T210,400 T260,260" />
                {/* Eurasia/Africa */}
                <path d="M480,100 Q600,60 750,90 T880,180 T800,280 T680,240 T480,100" />
                <path d="M500,210 Q580,260 550,380 T480,440 T450,350 T500,210" />
                {/* Australia */}
                <path d="M780,360 Q840,350 860,400 T790,440 Z" />
              </svg>

              {/* Glowing Pulse Points */}
              <div className="absolute top-[28%] left-[22%] group cursor-pointer">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-blue-500 opacity-75 animate-ping"></span>
                <span className="relative block h-2.5 w-2.5 rounded-full bg-blue-600"></span>
                <div className="absolute left-4 -top-2 scale-0 group-hover:scale-100 transition-all bg-gray-950 text-white text-[10px] px-2.5 py-1.5 rounded-xl border border-slate-800 shadow-xl whitespace-nowrap font-mono">NYC - Safe Score: 94</div>
              </div>

              <div className="absolute top-[48%] left-[28%] group cursor-pointer">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-emerald-400 opacity-75 animate-ping"></span>
                <span className="relative block h-2.5 w-2.5 rounded-full bg-emerald-500"></span>
                <div className="absolute left-4 -top-2 scale-0 group-hover:scale-100 transition-all bg-gray-950 text-white text-[10px] px-2.5 py-1.5 rounded-xl border border-slate-800 shadow-xl whitespace-nowrap font-mono">Rio - Safe Score: 81</div>
              </div>

              <div className="absolute top-[25%] left-[51%] group cursor-pointer">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-orange-500 opacity-75 animate-ping"></span>
                <span className="relative block h-2.5 w-2.5 rounded-full bg-orange-600"></span>
                <div className="absolute left-4 -top-2 scale-0 group-hover:scale-100 transition-all bg-gray-950 text-white text-[10px] px-2.5 py-1.5 rounded-xl border border-slate-800 whitespace-nowrap font-mono">London - Overcast Watch</div>
              </div>

              <div className="absolute top-[40%] left-[55%] group cursor-pointer">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-blue-500 opacity-75 animate-ping"></span>
                <span className="relative block h-2.5 w-2.5 rounded-full bg-blue-600"></span>
                <div className="absolute left-4 -top-2 scale-0 group-hover:scale-100 transition-all bg-gray-950 text-white text-[10px] px-2.5 py-1.5 rounded-xl border border-slate-800 shadow-xl whitespace-nowrap font-mono">Cairo - Safe Score: 88</div>
              </div>

              <div className="absolute top-[35%] left-[76%] group cursor-pointer">
                <span className="absolute inline-flex h-4 w-4 rounded-full bg-red-500 opacity-75 animate-ping"></span>
                <span className="relative block h-2.5 w-2.5 rounded-full bg-red-600"></span>
                <div className="absolute left-4 -top-2 scale-0 group-hover:scale-100 transition-all bg-gray-950 text-white text-[10px] px-2.5 py-1.5 rounded-xl border border-slate-800 shadow-xl whitespace-nowrap font-sans font-medium">Tokyo - Dense Crowd Jam</div>
              </div>
            </div>

            {/* Micro feed logs */}
            <div className="mt-3 text-left bg-slate-50/70 dark:bg-slate-900/40 rounded-2xl p-4 border border-gray-150 dark:border-slate-850 text-xs font-mono">
              <span className="text-gray-400 font-bold block mb-1.5 uppercase tracking-wider text-[9px]">Live Threat Grid Stream</span>
              <div className="flex justify-between text-blue-500 font-bold mb-0.5">
                <span>[08:14 UTC] Geo-Fence Check NYC: OK</span>
                <span className="text-emerald-500 font-sans font-extrabold text-xs">94/100 Safe</span>
              </div>
              <div className="flex justify-between text-amber-500">
                <span>[08:15 UTC] Japan Meteorological Agency Alert</span>
                <span className="text-amber-500 font-sans font-extrabold text-xs">Clear Forecast</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Real-time statistics section */}
      <section className="bg-gray-50/40 dark:bg-slate-900/10 rounded-[2.5rem] p-8 border border-gray-150/60 dark:border-slate-850">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => (
            <div key={idx} className="bg-white/75 dark:bg-[#070c20]/50 p-6 rounded-[2rem] border border-gray-200/40 dark:border-slate-800/80 text-left space-y-3.5 group hover:border-blue-500/35 hover:shadow-md transition-all duration-300 backdrop-blur-xs hover:translate-y-[-1px]">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold text-gray-400 dark:text-gray-450 uppercase tracking-widest font-mono leading-tight">{stat.label}</span>
                <div className="p-2.5 rounded-xl premium-icon-container bg-gradient-to-tr from-blue-500/10 to-indigo-500/5 dark:from-blue-500/10 group-hover:scale-105 transition-all duration-300 text-blue-600 dark:text-blue-400 border border-gray-200/20 dark:border-slate-800/60">
                  <stat.icon className={`h-4.5 w-4.5 ${stat.color} group-hover:scale-110 transition-transform`} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-3xl font-black font-display text-gray-950 dark:text-white group-hover:text-blue-500 transition-colors tracking-tight">{stat.value}</div>
                <div className="text-[10.5px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider font-sans">{stat.change}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Advanced Capabilities Feature Grid */}
      <section className="space-y-10 text-left">
        <div className="space-y-3 max-w-3xl">
          <h2 className="text-3xl font-extrabold font-display text-gray-900 dark:text-white">
            Comprehensive Smart-Shield Integration Space
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            Tourism bridges immediate hardware location tags with sovereign intelligence channels, ensuring security is active, offline-resilient, and precise.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feat, idx) => (
            <div key={idx} className="bg-white/70 dark:bg-[#070c20]/60 backdrop-blur-xs p-6 rounded-3xl border border-gray-200/40 dark:border-slate-800/80 flex gap-4.5 text-left shadow-md hover:shadow-lg dark:hover:shadow-blue-950/10 hover:border-blue-500/30 dark:hover:border-blue-500/20 transition-all duration-300 group hover:translate-y-[-2px]">
              <div className="p-3.5 rounded-2xl premium-icon-container bg-gradient-to-br from-blue-550/10 to-indigo-500/5 dark:from-blue-500/15 dark:to-indigo-500/5 text-blue-600 dark:text-blue-400 group-hover:scale-105 group-hover:-rotate-1 h-fit transition-all duration-300">
                <feat.icon className="h-6 w-6 group-hover:stroke-[2.5px] transition-all duration-300 text-blue-650 dark:text-blue-400" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-base font-extrabold font-display text-gray-950 dark:text-white group-hover:text-blue-500 transition-colors leading-snug">{feat.title}</h3>
                <p className="text-xs leading-relaxed text-gray-500 dark:text-gray-400 font-sans">{feat.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Quick Advice / Promo Panel */}
      <section className="relative rounded-3xl bg-blue-600 text-white overflow-hidden p-8 sm:p-12 text-left">
        <div className="absolute right-0 bottom-0 top-0 opacity-10 pointer-events-none w-1/2">
          <Globe className="w-full h-full transform translate-x-12 translate-y-12" />
        </div>
        <div className="max-w-2xl space-y-6">
          <div className="px-3 py-1 bg-white/10 rounded-full w-fit text-[11px] font-semibold uppercase tracking-widest font-mono">
            New Horizon Update
          </div>
          <h3 className="text-3xl sm:text-4xl font-extrabold font-display">
            Guardian Mode Interfacing Ready
          </h3>
          <p className="text-blue-100 leading-relaxed text-base">
            Instantly sync your real-time safety indices and active coordinates stream with family members. Guardian Mode works silently in the background, signaling notifications only during critical SOS parameters.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => onNavigate("profile")}
              className="px-5 py-2.5 rounded-lg bg-white text-blue-600 hover:bg-blue-50 font-semibold shadow-md inline-flex items-center gap-1.5 cursor-pointer text-sm"
            >
              Configure Guardian Plan <ChevronRight className="h-4 w-4" />
            </button>
            <button
              onClick={() => onNavigate("dashboard")}
              className="px-5 py-2.5 rounded-lg bg-blue-700/50 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer text-sm"
            >
              Analyze Hotspot Maps
            </button>
          </div>
        </div>
      </section>

      {/* Instant Notification Banner */}
      <AnimatePresence>
        {saveSuccessNotify && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 left-1/2 transform -translate-x-1/2 z-50 bg-emerald-500 text-white font-mono font-bold text-xs px-5 py-3 rounded-xl shadow-2xl border border-emerald-400 flex items-center gap-2"
          >
            <ShieldCheck className="h-5 w-5 animate-bounce" />
            <span>{saveSuccessNotify}</span>
            <button onClick={() => setSaveSuccessNotify(null)} className="ml-3 hover:opacity-80">
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Premium Multi-Tier Pricing Plans */}
      <section className="space-y-10">
        <div className="space-y-3 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-extrabold font-display text-gray-900 dark:text-white">
            Simple, Protection-Focused Pricing Space
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            No hidden costs. From standard local mapping lookups to integrated satellite-backed response forces, select your level of coverage.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          {packages.map((pkg, idx) => {
            const isMyActivePlan = currentPlan === pkg.name;
            return (
              <div
                key={idx}
                onMouseEnter={() => setActivePromoCard(idx)}
                onMouseLeave={() => setActivePromoCard(null)}
                className={`bg-white dark:bg-[#070b1e]/90 p-8 rounded-[2rem] border flex flex-col justify-between transition-all duration-300 relative ${
                  isMyActivePlan
                    ? "border-blue-500 bg-blue-500/5 dark:bg-blue-950/20 shadow-xl ring-2 ring-blue-500/50"
                    : "border-gray-200/60 dark:border-slate-855 shadow-xs"
                } ${activePromoCard === idx ? "transform -translate-y-1.5" : ""}`}
              >
                {pkg.active && (
                  <span className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-bold font-mono tracking-widest px-3.5 py-1 rounded-full uppercase shadow">
                    Most Preferred
                  </span>
                )}
                
                {isMyActivePlan && (
                  <span className="absolute -top-3 right-4 bg-emerald-500 text-white text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-full uppercase shadow flex items-center gap-1 animate-pulse">
                    <Check className="h-3 w-3" /> Selected Active
                  </span>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold font-display text-gray-850 dark:text-gray-100">{pkg.name}</h3>
                    <div className="flex items-baseline gap-1 mt-2 text-gray-900 dark:text-white">
                      <span className="text-4xl font-black font-display">{pkg.price}</span>
                      <span className="text-xs text-gray-400 font-semibold font-mono uppercase">/{pkg.period}</span>
                    </div>
                  </div>

                  <ul className="space-y-3 pt-4 border-t border-gray-100 dark:border-slate-800/60 text-sm">
                    {pkg.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex gap-2.5 items-start text-gray-600 dark:text-gray-300">
                        <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="text-xs">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => {
                      if (isMyActivePlan) {
                        setSaveSuccessNotify(`The "${pkg.name}" plan is already selected and active!`);
                        setTimeout(() => setSaveSuccessNotify(null), 3000);
                        return;
                      }
                      
                      if (pkg.price === "$0") {
                        // Free tier instantly activates
                        updateActivePlan(pkg.name);
                        setSaveSuccessNotify(`License set to: Free Voyager Solo!`);
                        setTimeout(() => setSaveSuccessNotify(null), 3000);
                      } else {
                        // Open professional checkout modal for premium plan
                        setCheckoutPlan(pkg);
                        setPaymentStep("form");
                      }
                    }}
                    className={`w-full py-3.5 rounded-2xl font-bold transition-all text-center cursor-pointer text-xs ${
                      isMyActivePlan
                        ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/35 cursor-default"
                        : pkg.name === "Voyager Elite Guardian"
                          ? "bg-blue-600 text-white hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/10 active:scale-98"
                          : "bg-gray-100 hover:bg-gray-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-gray-850 dark:text-gray-200 border border-transparent active:scale-98"
                    }`}
                  >
                    {isMyActivePlan ? "Active Protected Package" : pkg.cta}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Dynamic Premium Payment & Checkout Overlay Modal */}
        <AnimatePresence>
          {checkoutPlan && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 15 }}
                className="relative w-full max-w-lg overflow-hidden bg-white dark:bg-[#060a1cf5] text-slate-800 dark:text-gray-100 rounded-[2.5rem] border border-gray-100 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6"
              >
                {/* Close Button */}
                <button
                  onClick={() => setCheckoutPlan(null)}
                  className="absolute p-2 transition-colors rounded-full top-5 right-5 hover:bg-gray-100 dark:hover:bg-slate-900 cursor-pointer text-gray-400 hover:text-gray-100 dark:hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>

                {paymentStep === "form" && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setPaymentStep("processing");
                      const statuses = [
                        "Mapping device telemetry authorization...",
                        "Interfacing with families' security liaison keys...",
                        "Requesting Tourism authorization parameters...",
                        "Securing cryptographic payment gateway API...",
                        "Plan authorized & deployed!"
                      ];
                      let stepIdx = 0;
                      setProcessingStatus(statuses[0]);
                      const interval = setInterval(() => {
                        stepIdx++;
                        if (stepIdx < statuses.length) {
                          setProcessingStatus(statuses[stepIdx]);
                        } else {
                          clearInterval(interval);
                          updateActivePlan(checkoutPlan.name);
                          setPaymentStep("success");
                        }
                      }, 900);
                    }}
                    className="space-y-6 text-left"
                  >
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500/10 text-blue-500 text-[10px] font-mono font-bold uppercase rounded-full border border-blue-500/20">
                        <Lock className="h-3 w-3" /> Secure Crypto Gateway
                      </div>
                      <h3 className="text-2xl font-black font-display text-gray-900 dark:text-white leading-tight">
                        Activate {checkoutPlan.name}
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Gain immediate access to premium satellite tracking, priority AI forecasting, and dynamic SOS telemetry routing.
                      </p>
                    </div>

                    {/* Cost summary block */}
                    <div className="p-4 bg-gray-50 dark:bg-slate-900/50 rounded-2xl border border-gray-150 dark:border-slate-850 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-extrabold text-gray-800 dark:text-white">Protection Tier Subscription</p>
                        <p className="text-gray-450 dark:text-gray-350">{checkoutPlan.name} Plan Pack</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-black text-blue-500">{checkoutPlan.price}</p>
                        <p className="text-[10px] text-gray-400 font-mono tracking-widest uppercase">/{checkoutPlan.period}</p>
                      </div>
                    </div>

                    {/* Form inputs */}
                    <div className="space-y-4 text-xs font-mono">
                      <div className="space-y-1 block text-left">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Cardholder Family Name</label>
                        <input
                          type="text"
                          required
                          value={cardHolderName}
                          onChange={(e) => setCardHolderName(e.target.value)}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-900/60 font-sans text-xs text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                          placeholder="e.g. Alexis Carter"
                        />
                      </div>

                      <div className="space-y-1 block text-left">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Card Number</label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            maxLength={19}
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            className="w-full p-3 pl-10 rounded-xl border border-gray-200 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-900/60 text-xs text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium font-mono"
                            placeholder="4111 4821 9104 3822"
                          />
                          <CreditCard className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-gray-450 dark:text-gray-550" />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1 block text-left">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Expiry</label>
                          <input
                            type="text"
                            required
                            maxLength={5}
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full p-3 rounded-xl border border-gray-200 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-900/60 text-xs text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium font-mono"
                            placeholder="MM/YY"
                          />
                        </div>
                        <div className="space-y-1 block text-left">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Secure CVC</label>
                          <input
                            type="password"
                            required
                            maxLength={3}
                            value={cardCVC}
                            onChange={(e) => setCardCVC(e.target.value)}
                            className="w-full p-3 rounded-xl border border-gray-200 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-900/60 text-xs text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium font-mono"
                            placeholder="123"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-gray-150 dark:border-slate-800/65">
                      <button
                        type="submit"
                        className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl font-bold cursor-pointer hover:shadow-lg hover:shadow-blue-500/10 active:scale-[0.99] transition-all text-xs flex justify-center items-center gap-1.5"
                      >
                        <Shield className="h-4 w-4 shrink-0" /> Synchronize & Buy Security Lock
                      </button>
                      <p className="text-[10px] text-gray-400 dark:text-gray-500 text-center font-mono">
                        🔒 Authenticated with AES-GCM-256 standard localized cryptographic keys.
                      </p>
                    </div>
                  </form>
                )}

                {paymentStep === "processing" && (
                  <div className="py-12 flex flex-col items-center justify-center text-center space-y-6">
                    <div className="relative">
                      <span className="absolute inline-flex h-16 w-16 rounded-full bg-blue-500/20 animate-ping"></span>
                      <div className="h-14 w-14 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
                        <Activity className="h-6 w-6 animate-pulse" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="text-lg font-bold font-display text-gray-900 dark:text-white uppercase tracking-wider font-sans">Securing Protection Link</h4>
                      <div className="px-4 py-2 bg-gray-50 dark:bg-slate-900/70 border border-gray-150 dark:border-slate-850 rounded-xl">
                        <p className="text-xs font-mono font-bold text-blue-500 animate-pulse">{processingStatus}</p>
                      </div>
                    </div>
                  </div>
                )}

                {paymentStep === "success" && (
                  <div className="py-8 flex flex-col items-center justify-center text-center space-y-6">
                    <div className="h-16 w-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500 shadow-xl shadow-emerald-500/10 animate-bounce">
                      <ShieldCheck className="h-9 w-9" />
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="text-xl font-black font-display text-gray-900 dark:text-white">Security Plan Fully Activated</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm leading-relaxed px-2 font-sans">
                        The <span className="font-bold text-gray-850 dark:text-white font-mono">{checkoutPlan.name}</span> protection tier is active on this device. Live tracking networks and satellites have successfully synced configuration tags!
                      </p>
                    </div>

                    <div className="pt-4 w-full">
                      <button
                        onClick={() => {
                          setCheckoutPlan(null);
                          setPaymentStep("form");
                          // Redirect the user to profile to see their fully active dashboard or let them stay
                          onNavigate("profile");
                        }}
                        className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-2xl font-bold cursor-pointer text-xs shadow-md shadow-emerald-500/10 flex justify-center items-center gap-1"
                      >
                        Go to Travel Profile & Dashboard <ChevronRight className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </section>

      {/* Global Partner Network Showcase */}
      <section className="pt-4 border-t border-gray-100 dark:border-gray-900 space-y-6">
        <span className="text-center block text-xs font-mono font-bold tracking-widest text-gray-400 uppercase">
          Interlocked Travel & Emergency Support Alliances
        </span>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all">
          <div className="flex items-center gap-1.5 font-display font-black text-gray-600 dark:text-gray-400 text-base">
            <Compass className="h-5 w-5 text-blue-500" /> INTERPOL SYNC
          </div>
          <div className="flex items-center gap-1.5 font-display font-black text-gray-600 dark:text-gray-400 text-base">
            <Globe className="h-5 w-5 text-emerald-500" /> GLOBAL HEALTH NET
          </div>
          <div className="flex items-center gap-1.5 font-display font-black text-gray-600 dark:text-gray-400 text-base">
            <Shield className="h-5 w-5 text-amber-500" /> TOURI-SAFE SECURE
          </div>
          <div className="flex items-center gap-1.5 font-display font-black text-gray-600 dark:text-gray-400 text-base">
            <Activity className="h-5 w-5 text-red-500" /> RED CRES DISPATCH
          </div>
        </div>
      </section>

      {/* Footer Branding Area */}
      <footer className="pt-12 text-center text-xs text-gray-400 border-t border-gray-100 dark:border-gray-900 font-mono space-y-2">
        <p>© 2026 Tourism Intelligence Systems, Inc. In cooperation with Autonomous Security Alliances.</p>
        <p>Telemetry protocols authenticated under standard ITU systems. GPS indexing latency holds standard 1.2s delay.</p>
      </footer>
    </div>
  );
}
