import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, AlertCircle, FileUp, Mic, MapPin, CheckCircle, Clock, Volume2, User, PhoneCall, AlertOctagon, Heart, Send, Activity, Power, Trash2, HelpCircle } from "lucide-react";
import { IncidentReport, PriorityType } from "../types";

interface IncidentReportingProps {
  currentLocation: string;
  incidents: IncidentReport[];
  setIncidents: React.Dispatch<React.SetStateAction<IncidentReport[]>>;
}

export default function IncidentReporting({ currentLocation, incidents, setIncidents }: IncidentReportingProps) {
  // Form hooks
  const [reporterName, setReporterName] = useState(() => localStorage.getItem("traveler_name") || "");
  const [reporterPhone, setReporterPhone] = useState(() => localStorage.getItem("traveler_phone") || "");
  const [incidentType, setIncidentType] = useState("Theft");
  const [description, setDescription] = useState("");
  const [contactEmergencyName, setContactEmergencyName] = useState("");
  
  // Applet state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sosTriggered, setSosTriggered] = useState(false);
  const [sosCountdown, setSosCountdown] = useState(5);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const [audioRecorded, setAudioRecorded] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const incidentTypes = [
    { value: "Theft", label: "Theft / Lost Property" },
    { value: "Medical Emergency", label: "Medical / Heart Attack / Trauma" },
    { value: "Harassment", label: "Harassment / Safety Threats" },
    { value: "Lost Person", label: "Lost Person / Kidnap Warn" },
    { value: "Natural Disaster", label: "Natural Hazard / Fire Alert" },
    { value: "Suspicious Activity", label: "Suspicious Activity check" },
    { value: "Transport Issues", label: "Transport / Vehicle breakdown" }
  ];

  // Auto classification using our endpoint
  const handleSubmitReport = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!description.trim()) return;

    setIsSubmitting(true);
    try {
      const resp = await fetch("/api/incidents/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reporterName: reporterName || "Anonymous Traveler",
          reporterPhone: reporterPhone || "none",
          incidentType,
          description,
          location: currentLocation,
          contactEmergencyName: contactEmergencyName || "Family Beacon",
          audioRecorded
        })
      });

      if (!resp.ok) throw new Error("Server triage degradation");
      const parsed = await resp.json();

      const newReport: IncidentReport = {
        id: "rep-" + Date.now(),
        reporterName: reporterName || "Anonymous Traveler",
        reporterPhone: reporterPhone || "N/A",
        incidentType: parsed.category || incidentType,
        description,
        location: currentLocation,
        contactEmergencyName: contactEmergencyName || "N/A",
        priority: parsed.priority as PriorityType || "Moderate",
        riskScore: parsed.riskScore || 50,
        summary: parsed.summary || "Manual dispatch logged.",
        guideInstructions: parsed.guideInstructions || "Verify situational safety locks.",
        recommendedAuthority: parsed.recommendedAuthority || "Municipal First Responders",
        status: "AI Checked",
        timestamp: new Date().toLocaleString(),
        audioRecorded
      };

      setIncidents((prev) => [newReport, ...prev]);
      
      // Reset form fields
      setDescription("");
      setReporterName("");
      setReporterPhone("");
      setContactEmergencyName("");
      setAudioRecorded(false);
      setSelectedFile(null);
    } catch (err) {
      console.error(err);
      // Fallback local classification
      const randomScore = Math.floor(Math.random() * 40) + 40;
      const newReport: IncidentReport = {
        id: "rep-local-" + Date.now(),
        reporterName: reporterName || "Anonymous Traveler",
        reporterPhone: reporterPhone || "N/A",
        incidentType,
        description,
        location: currentLocation,
        contactEmergencyName: contactEmergencyName || "N/A",
        priority: incidentType === "Medical Emergency" ? "Critical" : "Moderate",
        riskScore: randomScore,
        summary: "Autonomous emergency log triggered under safety matrix protocols.",
        guideInstructions: "1. Stay in highly lit areas.\n2. Keep your device safe.\n3. Wait for local police sync.",
        recommendedAuthority: "Local Tourist Command HQ",
        status: "Reported",
        timestamp: new Date().toLocaleString()
      };
      setIncidents((prev) => [newReport, ...prev]);
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Emergency SOS Immediate dispatch sequencer count
  const handleSosTrigger = () => {
    if (sosTriggered) {
      // Abort
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setSosTriggered(false);
      setSosCountdown(5);
    } else {
      setSosTriggered(true);
      setSosCountdown(5);
      timerRef.current = setInterval(() => {
        setSosCountdown((prev) => {
          if (prev <= 1) {
            if (timerRef.current) {
              clearInterval(timerRef.current);
              timerRef.current = null;
            }
            // Execute automated absolute SOS dispatch report
            executeEmergencySosReport();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  const executeEmergencySosReport = async () => {
    try {
      const resp = await fetch("/api/incidents/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reporterName: "CRITICAL SOS ACTIVATED",
          reporterPhone: "Immediate GPS Stream Channel",
          incidentType: "Emergency SOS Button Push",
          description: "EMERGENCY: User activated immediate SOS button countdown. GPS Coordinates and audio broadcast channels locked active.",
          location: currentLocation,
          contactEmergencyName: "Family Beacon Direct Alert",
          audioRecorded: true
        })
      });

      const parsed = await resp.json();
      const newReport: IncidentReport = {
        id: "rep-sos-" + Date.now(),
        reporterName: "CRITICAL SOS ACTIVATED",
        reporterPhone: "Live GPS Active Link",
        incidentType: "Emergency SOS Triggered",
        description: "EMERGENCY: User activated immediate SOS beacon. GPS active, dispatching local responders.",
        location: currentLocation,
        contactEmergencyName: "Direct Guardian Beacon",
        priority: "Critical",
        riskScore: 99,
        summary: "AUTOMATED SATELLITE DISPATCH: Immediate response teams routes recalculated. High authority channels notified.",
        guideInstructions: "IMMEDIATE STEPS:\n1. Find secure shelter or a staffed hotel lobby.\n2. Do NOT approach unrecognized third party groups.\n3. Secure beacon audio recording channels remain live.",
        recommendedAuthority: "State Air Ambulance & Tactical Police Command",
        status: "Dispatched",
        timestamp: new Date().toLocaleString(),
        audioRecorded: true
      };

      setIncidents((prev) => [newReport, ...prev]);
    } catch (e) {
      console.error(e);
    } finally {
      setSosTriggered(false);
      setSosCountdown(5);
    }
  };

  const handleUpdateStatus = (id: string, newStatus: "Dispatched" | "In Progress" | "Resolved") => {
    setIncidents(prev =>
      prev.map(inc => inc.id === id ? { ...inc, status: newStatus } : inc)
    );
  };

  const handleRemoveIncident = (id: string) => {
    setIncidents(prev => prev.filter(inc => inc.id !== id));
  };

  const handleMicToggle = () => {
    if (isRecording) {
      setIsRecording(false);
      setAudioRecorded(true);
    } else {
      setIsRecording(true);
      setAudioRecorded(false);
    }
  };

  return (
    <div className="space-y-8 py-2 text-left font-sans">
      
      {/* Mega Red Flashing SOS Button Section */}
      <section className="bg-gradient-to-r from-red-600 to-orange-500 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-xl shadow-red-500/15">
        <div className="absolute top-0 right-0 opacity-10 font-bold font-mono text-9xl tracking-tighter transform translate-x-12 select-none">
          SOS
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center relative">
          <div className="md:col-span-8 space-y-3">
            <div className="px-3 py-1 bg-white/20 rounded-full w-fit text-[10px] font-bold font-mono tracking-widest uppercase uppercase">
              Armed Satellite Guardian Enabled
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold font-display leading-[1.1]">
              One-Click Instant Autonomous Rescue Beacon
            </h2>
            <p className="text-red-100 max-w-2xl text-sm leading-relaxed">
              Activating this button immediately initiates our AI tactical priority sequence: captures short surroundings audio, shares active GPS stream with emergency response center, and transmits real-time alert logs to family guardians.
            </p>
          </div>

          <div className="md:col-span-4 flex justify-center relative py-4">
            {/* Ambient glowing aura around the SOS trigger */}
            {sosTriggered && (
              <div className="absolute inset-0 m-auto h-40 w-40 rounded-full bg-red-500/40 blur-2xl animate-ping" />
            )}
            <div className="absolute inset-0 m-auto h-36 w-36 rounded-full border border-dashed border-white/20 animate-spin" style={{ animationDuration: "15s" }} />
            
            <button
              onClick={handleSosTrigger}
              className={`h-32 w-32 rounded-full flex flex-col items-center justify-center border-4 border-white font-extrabold text-sm shadow-2xl transition-transform active:scale-95 cursor-pointer relative z-10 ${
                sosTriggered 
                  ? "bg-white text-rose-650 ring-8 ring-rose-500/20 scale-105" 
                  : "bg-gradient-to-br from-rose-600 to-red-800 hover:from-rose-500 hover:to-red-700 text-white shadow-rose-950/40 hover:shadow-rose-500/30"
              }`}
              id="sos-trigger-btn"
            >
              {sosTriggered ? (
                <>
                  <span className="text-5xl font-black font-display leading-none tracking-tight animate-bounce">{sosCountdown}</span>
                  <span className="text-[8px] font-bold font-mono uppercase tracking-widest mt-1 bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded">TAP TO CANCEL</span>
                </>
              ) : (
                <>
                  <Power className="h-8 w-8 animate-pulse mb-1 text-rose-200" />
                  <span className="text-2xl font-black font-display tracking-widest uppercase bg-clip-text text-transparent bg-gradient-to-r from-white to-rose-100">SOS</span>
                  <span className="text-[8px] font-bold font-mono tracking-widest uppercase text-rose-200 block mt-1">TAP TO TRIGGER</span>
                </>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* Main reporting form and active list split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Form panel */}
        <div className="lg:col-span-5 bg-white dark:bg-gray-950 p-6 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-5 shadow-xs">
          <div>
            <h3 className="text-base font-extrabold font-display text-gray-800 dark:text-gray-150">Transmit Security/Incident Report</h3>
            <p className="text-[11px] text-gray-400 font-mono">Autonomous AI categorizes priority parameters upon submit</p>
          </div>

          <form onSubmit={handleSubmitReport} className="space-y-4 text-xs font-sans">
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Reporter Full Name</label>
                <input
                  type="text"
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="e.g. Alexis Carter"
                  className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Reporter Phone</label>
                <input
                  type="tel"
                  value={reporterPhone}
                  onChange={(e) => setReporterPhone(e.target.value)}
                  placeholder="e.g. +1 (555) 481-921"
                  className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1 col-span-2">
                <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Primary Alert Node Classification</label>
                <select
                  value={incidentType}
                  onChange={(e) => setIncidentType(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-xs cursor-pointer"
                >
                  {incidentTypes.map((t) => (
                    <option key={t.value} value={t.value} className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Critical Event Descriptors (Include weapon type, suspect traits if any)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Where precisely are you? What sequence occurred? Does medical emergency currently exist?"
                rows={3}
                required
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-sans resize-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Direct Emergency Contact Person / Liaison Name</label>
              <input
                type="text"
                value={contactEmergencyName}
                onChange={(e) => setContactEmergencyName(e.target.value)}
                placeholder="e.g. Richard Carter (Father) - +1 881 291"
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Captures voice / image widgets */}
            <div className="grid grid-cols-2 gap-4 pt-1">
              
              <button
                type="button"
                onClick={handleMicToggle}
                className={`flex gap-2 items-center justify-center p-3 rounded-xl border text-xs font-bold cursor-pointer transition-colors ${
                  isRecording 
                    ? "bg-red-500 text-white border-red-500 animate-pulse" 
                    : audioRecorded 
                    ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30" 
                    : "bg-gray-50 hover:bg-gray-100 dark:bg-gray-900 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 border-gray-200/50 dark:border-gray-850"
                }`}
              >
                <Mic className="h-4 w-4 shrink-0" />
                <span>{isRecording ? "Recording..." : audioRecorded ? "Audio Saved ✓" : "Record Voice log"}</span>
              </button>

              <label className="flex gap-2 items-center justify-center p-3 rounded-xl border text-xs font-bold cursor-pointer bg-gray-50 hover:bg-gray-100 dark:bg-gray-900 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 border-gray-200/50 dark:border-gray-850 transition-colors">
                <FileUp className="h-4 w-4 shrink-0" />
                <span className="truncate">{selectedFile ? selectedFile.name : "Attach Image/Video"}</span>
                <input
                  type="file"
                  className="hidden"
                  accept="image/*,video/*"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setSelectedFile(e.target.files[0]);
                    }
                  }}
                />
              </label>

            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer border border-transparent"
              id="submit-incident-btn"
            >
              <Send className="h-4 w-4" />
              {isSubmitting ? "Processing AI Category Classification..." : "Transmit Secure Report to AI Dispatch"}
            </button>

          </form>

          <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl text-[10px] text-amber-700 dark:text-amber-400 leading-normal flex gap-2">
            <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
            <p>
              By tapping submit, you auto-authorize real-time location telemetry to local law authorities strictly for emergency routing.
            </p>
          </div>
        </div>

        {/* Real-time feed status track */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex justify-between items-center pb-2 border-b border-gray-100 dark:border-gray-950">
            <h3 className="text-base font-extrabold font-display text-gray-800 dark:text-gray-200">Active Incident Feed & Track</h3>
            <span className="px-2 py-0.5 bg-blue-500/10 text-blue-500 font-mono text-[10px] uppercase font-bold rounded-full">
              {incidents.length} Active Dispatch Events
            </span>
          </div>

          <div className="space-y-4 overflow-y-auto max-h-[620px] pr-1">
            <AnimatePresence initial={false}>
              {incidents.length === 0 ? (
                <div className="bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-900 rounded-2xl p-12 text-center text-gray-400 space-y-3 font-mono text-xs">
                  <Shield className="h-12 w-12 text-gray-300 mx-auto" />
                  <p>No active incidents flagged or reported in this session.</p>
                  <p className="text-[10px] text-gray-500">Your current location grid index is completely secure.</p>
                </div>
              ) : (
                incidents.map((inc) => {
                  
                  // Color configuration based on priority
                  let priorityColor = "bg-green-500/10 text-green-500 border-green-500/20";
                  if (inc.priority === "Moderate") priorityColor = "bg-blue-500/10 text-blue-500 border-blue-500/20";
                  if (inc.priority === "High") priorityColor = "bg-orange-500/10 text-orange-500 border-orange-500/20";
                  if (inc.priority === "Critical") priorityColor = "bg-red-500/10 text-red-500 border-red-500/20 animate-pulse";

                  return (
                    <motion.div
                      key={inc.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="bg-white dark:bg-gray-950 p-5 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-4 text-left shadow-xs relative"
                    >
                      {/* Close/Remove action */}
                      <button
                        onClick={() => handleRemoveIncident(inc.id)}
                        className="absolute top-4 right-4 p-1 text-gray-350 hover:text-red-500 rounded hover:bg-gray-50 dark:hover:bg-gray-900 cursor-pointer"
                        title="Remove incident log from session view"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>

                      {/* Header block */}
                      <div className="flex flex-wrap items-center gap-3">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold border uppercase tracking-wider ${priorityColor}`}>
                          {inc.priority} Priority
                        </span>
                        
                        <span className="text-xs text-gray-400 font-mono">{inc.timestamp}</span>
                        <span className="text-xs text-gray-400">•</span>
                        <span className="text-xs text-gray-500 font-semibold font-mono flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5 text-blue-500" /> {inc.location}
                        </span>
                      </div>

                      {/* Event category title */}
                      <div className="space-y-1 block">
                        <h4 className="text-base font-extrabold font-display text-gray-850 dark:text-white uppercase tracking-tight">
                          {inc.incidentType}
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-sans italic">
                          &quot;{inc.description}&quot;
                        </p>
                      </div>

                      {/* AI auto triage summary info line */}
                      <div className="p-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl space-y-2 border border-gray-100/50 dark:border-gray-900 text-xs">
                        <div className="flex justify-between items-center text-[10px] font-bold font-mono tracking-widest text-gray-400 uppercase">
                          <span>AI Autonomous Triage Diagnosis</span>
                          <span className="text-blue-500">Risk Severity Score: {inc.riskScore}</span>
                        </div>
                        <p className="text-gray-650 dark:text-gray-300 leading-normal">
                          {inc.summary}
                        </p>
                        <p className="text-gray-650 dark:text-gray-300 font-mono text-[10px] text-blue-600 dark:text-blue-400">
                          <strong>Recommended Rescue Division:</strong> {inc.recommendedAuthority}
                        </p>
                      </div>

                      {/* Active Step Progress workflow timeline */}
                      <div className="pt-2">
                        <span className="text-[10px] font-bold font-mono text-gray-400 uppercase tracking-widest block mb-2">Live Response Routing Tracks</span>
                        <div className="grid grid-cols-5 text-center text-[9px] font-mono select-none font-bold">
                          {[
                            { state: "Reported", label: "LOGGED" },
                            { state: "AI Checked", label: "TRIAGED" },
                            { state: "Dispatched", label: "DISPATCH" },
                            { state: "In Progress", label: "IN PROGRESS" },
                            { state: "Resolved", label: "RESOLVED ✓" }
                          ].map((step, idx, arr) => {
                            // Find active sequence
                            const statuses = ["Reported", "AI Checked", "Dispatched", "In Progress", "Resolved"];
                            const currentIdx = statuses.indexOf(inc.status);
                            const stepIdx = statuses.indexOf(step.state);
                            const isActive = stepIdx <= currentIdx;

                            return (
                              <div key={step.state} className="space-y-1 text-center relative flex flex-col items-center">
                                {/* Connection link line */}
                                {idx < arr.length - 1 && (
                                  <div className={`absolute top-2.5 left-[50%] right-[-50%] h-1 transition-colors ${
                                    stepIdx < currentIdx ? "bg-emerald-500" : "bg-gray-200 dark:bg-gray-800"
                                  }`} />
                                )}

                                <div className={`h-5 w-5 rounded-full flex items-center justify-center relative z-10 text-[10px] font-bold border transition-all ${
                                  isActive 
                                    ? "bg-emerald-500 text-white border-emerald-500" 
                                    : "bg-gray-100 dark:bg-gray-900 text-gray-400 border-gray-200 dark:border-gray-800"
                                }`}>
                                  {stepIdx < currentIdx ? "✓" : idx + 1}
                                </div>
                                <span className={isActive ? "text-emerald-500" : "text-gray-400"}>
                                  {step.label}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Live emergency guide banner */}
                      <div className="p-3.5 rounded-xl bg-orange-500/5 border border-orange-500/10 text-xs text-orange-850 dark:text-orange-400 space-y-1 block leading-relaxed font-sans">
                        <span className="font-bold flex items-center gap-1 text-orange-600 dark:text-orange-400 font-display">
                          <AlertOctagon className="h-4.5 w-4.5" /> Emergency Guide Action Required:
                        </span>
                        <div className="whitespace-pre-line text-[11px]">
                          {inc.guideInstructions}
                        </div>
                      </div>

                      {/* Admin dispatcher emulator controllers */}
                      <div className="pt-2 border-t border-gray-100 dark:border-gray-900 flex flex-wrap justify-between items-center gap-3">
                        <span className="text-[10px] font-mono text-gray-400">Dispatcher Control Override:</span>
                        <div className="flex gap-1 bg-gray-50 dark:bg-gray-900 p-1 rounded-lg border border-gray-100 dark:border-gray-850">
                          <button
                            onClick={() => handleUpdateStatus(inc.id, "Dispatched")}
                            className="px-2.5 py-1 rounded bg-white hover:bg-gray-100 dark:bg-gray-850 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 text-[10px] font-bold text-gray-500 dark:text-gray-300 cursor-pointer"
                          >
                            Dispatch Forces
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(inc.id, "In Progress")}
                            className="px-2.5 py-1 rounded bg-white hover:bg-gray-100 dark:bg-gray-850 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 text-[10px] font-bold text-gray-500 dark:text-gray-300 cursor-pointer"
                          >
                            En Route
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(inc.id, "Resolved")}
                            className="px-2.5 py-1 rounded bg-emerald-500 hover:bg-emerald-600 text-white text-[10px] font-bold cursor-pointer"
                          >
                            Mark Restored
                          </button>
                        </div>
                      </div>

                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </div>
        </div>

      </div>

    </div>
  );
}
