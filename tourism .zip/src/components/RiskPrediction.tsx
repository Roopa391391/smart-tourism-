import React, { useState } from "react";
import { motion } from "motion/react";
import { Shield, MapPin, AlertCircle, TrendingUp, Cpu, Sparkles, Activity, CheckCircle, Crosshair, ArrowRight, ShieldCheck } from "lucide-react";

interface RiskPredictionProps {
  currentLocation: string;
}

export default function RiskPrediction({ currentLocation }: RiskPredictionProps) {
  const [selectedTopic, setSelectedTopic] = useState<"crime" | "crowd" | "weather" | "health">("crime");

  const riskTimelines = [
    { hour: "08:00 UTC", level: "Optimal Low", crowds: "Minor (8%)", crimeForecast: "Zero alerts logged." },
    { hour: "12:00 UTC", level: "Optimal Low", crowds: "Medium transit (24%)", crimeForecast: "Zero alerts." },
    { hour: "16:00 UTC", level: "Moderate Watch", crowds: "Heavy commute corridor (48%)", crimeForecast: "Scam focus near main steps." },
    { hour: "20:00 UTC", level: "High Alert Index", crowds: "Severe tourist gather (84%)", crimeForecast: "Watch personal belongings; pocket thieves active." },
    { hour: "00:00 UTC", level: "Moderate Watch", crowds: "Low pedestrian densities (12%)", crimeForecast: "Avoid isolated side streets." }
  ];

  const predictiveScenarios = {
    crime: {
      title: "Machine-Learned Crime Forecasting Matrix",
      confidence: "94.2% AI Accuracy",
      description: "Applies multi-source crime incident logs, city camera analysis loops, and temporal schedules to forecast pocket theft, fraudulent retail traps and transit scam clusters.",
      threat: "Medium Profile",
      colorClass: "text-amber-500",
      actions: [
        "Store high-value cards inside secure chest bags.",
        "Maintain normal momentum; do not accept unprompted local brochures or floral gifts.",
        "Utilize verified SafeVoyage Gold hospitality radius limits."
      ]
    },
    crowd: {
      title: "Real-Time Crowd Density & Stamped Mitigation",
      confidence: "88.7% AI Accuracy",
      description: "Combines local mobile network metrics and public sector heat indicators to detect bottlenecking in pedestrian avenues, potential stampede traps during rallies, or heavy retail jams.",
      threat: "Low Profile",
      colorClass: "text-emerald-500",
      actions: [
        "Move parallel to high transit lines; avoid bottlenecks near tube gates.",
        "Secure pocket assets firmly prior to passing tube escalators.",
        "Locate emergency exit lines marked with light green indicators."
      ]
    },
    weather: {
      title: "Advanced Climatic Hazard & Natural Disaster Watch",
      confidence: "91% AI Accuracy",
      description: "Monitors satellite weather maps, local barometric dials, and seismic meters to pre-warn about sudden flash floods, severe heat strokes, or coastal tide fluctuations.",
      threat: "Low Profile",
      colorClass: "text-emerald-500",
      actions: [
        "Carry lightweight rain-shielding gear during evening commutes.",
        "Keep absolute local weather emergency notifications on active alert.",
        "Store water supply limits for outer urban mapping excursions."
      ]
    },
    health: {
      title: "Geo-Spatial Health Risk & Medical Alert Map",
      confidence: "85.4% AI Accuracy",
      description: "Integrates public hospital records, temperature shifts, and localized sewage filtration indices to detect localized allergy spikes or active stomach flu zones.",
      threat: "Low Profile",
      colorClass: "text-emerald-500",
      actions: [
        "Verify certified sealed drinking water is used within port zones.",
        "Avoid raw food counters placed in central open air alleyways.",
        "Verify medical card emergency contacts are verified and saved."
      ]
    }
  };

  const currScenario = predictiveScenarios[selectedTopic];

  return (
    <div className="space-y-8 py-2 text-left font-sans">
      
      {/* Top Welcome Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100 dark:border-gray-950">
        <div className="space-y-1 text-left">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-500 font-mono text-[10px] font-bold uppercase uppercase">
            <Cpu className="h-4 w-4" /> Machine Learning Engine Online
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold font-display text-gray-850 dark:text-white leading-tight">
            AI Safety Risk Prediction Engine
          </h2>
          <p className="text-xs text-gray-400 font-mono">Target Node Coordinate: {currentLocation}</p>
        </div>

        <div className="flex gap-1.5 items-center bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-850 rounded-xl p-2 font-mono text-xs text-gray-500">
          <Sparkles className="h-4.5 w-4.5 text-blue-500 animate-pulse" />
          <span>Calculated Risk Confidence: <strong>94.2%</strong></span>
        </div>
      </div>

      {/* Analytics Controller Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Category Picker + Scenario */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main selection tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { id: "crime", label: "Crime Forecast", color: "text-amber-500" },
              { id: "crowd", label: "Crowd Risks", color: "text-blue-500" },
              { id: "weather", label: "Weather Hazards", color: "text-orange-500" },
              { id: "health", label: "Health Logs", color: "text-emerald-500" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTopic(tab.id as any)}
                className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedTopic === tab.id 
                    ? "bg-white dark:bg-gray-950 border-blue-500 shadow-md ring-1 ring-blue-500" 
                    : "bg-white dark:bg-gray-950 border-gray-100 dark:border-gray-900 hover:border-gray-200"
                }`}
              >
                <span className={`text-[10px] font-bold font-mono tracking-widest block uppercase ${tab.color}`}>SYSTEM NODE</span>
                <span className="text-sm font-extrabold font-display text-gray-850 dark:text-white block mt-1">{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Active analytical report display */}
          <div className="bg-white dark:bg-gray-950 p-6 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-5 shadow-xs text-left relative overflow-hidden">
            
            {/* Glowing background hint */}
            <div className="absolute top-0 right-0 h-44 w-44 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />

            <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-gray-900">
              <h3 className="text-lg font-bold font-display text-gray-850 dark:text-white">
                {currScenario.title}
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/10 text-blue-500 font-mono font-bold tracking-widest uppercase">
                {currScenario.confidence}
              </span>
            </div>

            <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-350">
              {currScenario.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 text-left">
              
              {/* Primary risk indicator */}
              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl border border-gray-100 dark:border-gray-900 space-y-1 block">
                <span className="text-[10px] font-bold font-mono text-gray-400 uppercase tracking-widest block">Evaluated Threat Tier</span>
                <span className={`text-lg font-extrabold font-display flex items-center gap-1.5 ${currScenario.colorClass}`}>
                  <ShieldCheck className="h-5 w-5" /> {currScenario.threat}
                </span>
                <p className="text-[10px] text-gray-400 font-mono">Derived from last 48-hour municipal incident feed</p>
              </div>

              {/* Confidence metric score */}
              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl border border-gray-100 dark:border-gray-900 space-y-1 block">
                <span className="text-[10px] font-bold font-mono text-gray-400 uppercase tracking-widest block">Anomaly Scoring Rate</span>
                <span className="text-lg font-extrabold font-display text-blue-600 dark:text-blue-400 flex items-center gap-1.5 font-mono">
                  <Activity className="h-5 w-5 animate-pulse" /> 12% Alerts Ratio
                </span>
                <p className="text-[10px] text-gray-400 font-mono">Calculated over absolute spatial baseline</p>
              </div>

            </div>

            {/* Strategic recommendations timeline checklist */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold font-mono text-gray-400 uppercase tracking-widest block">AI Recommended Active Tactics:</span>
              <ul className="space-y-2.5">
                {currScenario.actions.map((act, i) => (
                  <li key={i} className="flex gap-2.5 items-start text-xs text-gray-600 dark:text-gray-400 bg-blue-500/5 p-3 rounded-xl border border-blue-500/10 hover:bg-blue-500/10 transition-colors">
                    <CheckCircle className="h-4.5 w-4.5 text-blue-500 shrink-0 mt-0.5" />
                    <span>{act}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

        </div>

        {/* Right Side: Risk Timeline Score meters */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Real-time Temporal hazard tracker logs */}
          <div className="bg-white dark:bg-gray-950 p-5 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-4 shadow-xs text-left">
            <div>
              <h4 className="text-sm font-extrabold font-display text-gray-850 dark:text-white uppercase tracking-tight">Geo-Temporal Threat Timeline</h4>
              <p className="text-[10px] text-gray-400 font-mono">Forecasting threat probability indices over 24H cycle</p>
            </div>

            <div className="space-y-3">
              {riskTimelines.map((line, idx) => {
                
                // Color configuration
                let stepColor = "text-emerald-500";
                let barColor = "bg-emerald-500";
                if (line.level.includes("Moderate")) {
                  stepColor = "text-amber-500";
                  barColor = "bg-amber-500";
                } else if (line.level.includes("High")) {
                  stepColor = "text-red-500";
                  barColor = "bg-red-500";
                }

                return (
                  <div key={idx} className="p-3 bg-gray-50/50 dark:bg-gray-900/30 rounded-xl space-y-2 border border-gray-100/50 dark:border-gray-900 text-xs">
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className="font-bold text-gray-400">{line.hour}</span>
                      <span className={`font-bold uppercase tracking-wider ${stepColor}`}>{line.level}</span>
                    </div>

                    <div className="flex justify-between text-xs font-semibold text-gray-700 dark:text-gray-350">
                      <span>{line.crimeForecast}</span>
                    </div>

                    <div className="flex justify-between text-[11px] text-gray-400">
                      <span>Transit density index:</span>
                      <span>{line.crowds}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick disclaimer info card */}
          <div className="p-4 bg-orange-600 rounded-2xl text-white space-y-2 text-xs relative overflow-hidden shadow-md">
            <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none w-1/3">
              <Shield className="w-full h-full" />
            </div>
            <h5 className="font-extrabold font-display flex items-center gap-1">
              <AlertCircle className="h-4.5 w-4.5 animate-pulse" /> Guardian Threshold Alerts ACTIVE
            </h5>
            <p className="text-orange-100 leading-normal text-[11px]">
              If safety score parameters within your target node coordinate drift below 65, Guardian alert channels activate to transmit defensive fallback warnings automatically.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
