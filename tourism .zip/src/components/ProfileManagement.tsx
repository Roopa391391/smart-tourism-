import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { User, Shield, Phone, Heart, Settings, BatteryCharging, CheckSquare, ShieldCheck, ToggleLeft, ToggleRight, ArrowRight, Save, KeyRound} from "lucide-react";
import { GuardModeUser } from "../types";

export default function ProfileManagement() {
  const [activeTab, setActiveTab] = useState<"details" | "medical" | "guardian" | "security">("details");
  
  // Dynamic current subscription plan state
  const [currentPlan, setCurrentPlan] = useState<string>(() => localStorage.getItem("userPlan") || "Voyager Solo");

  React.useEffect(() => {
    const syncPlan = () => {
      setCurrentPlan(localStorage.getItem("userPlan") || "Voyager Solo");
    };
    window.addEventListener("storage", syncPlan);
    return () => window.removeEventListener("storage", syncPlan);
  }, []);

  // Profile settings state hooks initialized from localStorage with robust defaults
  const [name, setName] = useState(() => localStorage.getItem("traveler_name") || "Alexis Carter");
  const [phone, setPhone] = useState(() => localStorage.getItem("traveler_phone") || "+1 (555) 481-921");
  const [email, setEmail] = useState(() => localStorage.getItem("traveler_email") || "alexis.carter@safevoyage.org");
  const [itinerary, setItinerary] = useState(() => localStorage.getItem("traveler_itinerary") || "San Francisco -> London -> Tokyo (Aug 2026)");
  
  // Medical card details hooks initialized from localStorage with robust defaults
  const [bloodType, setBloodType] = useState(() => localStorage.getItem("traveler_bloodType") || "O Positive");
  const [allergies, setAllergies] = useState(() => localStorage.getItem("traveler_allergies") || "Penicillin, Peanuts");
  const [meds, setMeds] = useState(() => localStorage.getItem("traveler_meds") || "Normal daily vitamins");

  // Guardian Mode setup state initialized from localStorage with robust defaults
  const [guardianName, setGuardianName] = useState(() => localStorage.getItem("traveler_guardianName") || "Richard Carter");
  const [guardianPhone, setGuardianPhone] = useState(() => localStorage.getItem("traveler_guardianPhone") || "+1 (555) 911-303");
  const [guardianEmail, setGuardianEmail] = useState(() => localStorage.getItem("traveler_guardianEmail") || "rct.carter@familybeacon.org");
  
  // Security locks state hooks initialized from localStorage
  const [biometricEnabled, setBiometricEnabled] = useState(() => {
    const val = localStorage.getItem("traveler_biometricEnabled");
    return val !== null ? val === "true" : true;
  });
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(() => {
    const val = localStorage.getItem("traveler_twoFactorEnabled");
    return val !== null ? val === "true" : false;
  });
  const [privacyMode, setPrivacyMode] = useState(() => {
    const val = localStorage.getItem("traveler_privacyMode");
    return val !== null ? val === "true" : true;
  });

  // Simulated Save Banner Notification
  const [saveBanner, setSaveBanner] = useState(false);

  // Trigger Save Feedback
  const triggerSaveNotify = () => {
    setSaveBanner(true);
    setTimeout(() => setSaveBanner(false), 3000);
  };


  // Specific Save Handler Functions to persist in LocalStorage
  const saveTravelParameters = () => {
    localStorage.setItem("traveler_name", name);
    localStorage.setItem("traveler_phone", phone);
    localStorage.setItem("traveler_email", email);
    localStorage.setItem("traveler_itinerary", itinerary);
    // Dispatch a global storage event in case header/assistant need the updated name
    window.dispatchEvent(new Event("storage"));
    triggerSaveNotify();
  };

  const saveMedicalParameters = () => {
    localStorage.setItem("traveler_bloodType", bloodType);
    localStorage.setItem("traveler_allergies", allergies);
    localStorage.setItem("traveler_meds", meds);
    triggerSaveNotify();
  };

  const saveGuardianParameters = () => {
    localStorage.setItem("traveler_guardianName", guardianName);
    localStorage.setItem("traveler_guardianPhone", guardianPhone);
    localStorage.setItem("traveler_guardianEmail", guardianEmail);
    triggerSaveNotify();
  };

  const toggleBiometric = () => {
    const newVal = !biometricEnabled;
    setBiometricEnabled(newVal);
    localStorage.setItem("traveler_biometricEnabled", String(newVal));
    triggerSaveNotify();
  };

  const toggleTwoFactor = () => {
    const newVal = !twoFactorEnabled;
    setTwoFactorEnabled(newVal);
    localStorage.setItem("traveler_twoFactorEnabled", String(newVal));
    triggerSaveNotify();
  };

  const togglePrivacyMode = () => {
    const newVal = !privacyMode;
    setPrivacyMode(newVal);
    localStorage.setItem("traveler_privacyMode", String(newVal));
    triggerSaveNotify();
  };

  // Mock Guard Mode details
  const guardUsers: GuardModeUser[] = [
    {
      id: "gu-1",
      name: "Richard Carter",
      relationship: "Father",
      phone: "+1 (555) 911-303",
      email: "rct.carter@familybeacon.org",
      lastActiveLocation: "Times Square Metro Terminal",
      lastActiveTime: "2 mins ago",
      batteryLevel: 94,
      safetyScoreCurrent: 94,
      activeIncidents: 0
    }
  ];

  return (
    <div className="space-y-8 py-2 text-left font-sans">
      
      {/* Top Welcome Card */}
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-150 dark:border-gray-900 text-left">
        <div className="space-y-0.5 block">
          <h2 className="text-2xl md:text-3xl font-extrabold font-display text-gray-850 dark:text-white leading-tight">
            Tourist Profile & Security Panel
          </h2>
          <p className="text-xs text-gray-400 font-mono">Configure travel itineraries, guardian safety liaisons, and biometric credentials</p>
        </div>

        <div className="flex flex-row items-center gap-4">
          <div className="flex flex-col md:items-end text-left md:text-right">
            <span className="text-[9px] font-bold text-gray-405 dark:text-gray-400 font-mono tracking-widest uppercase block">Coverage Shield</span>
            <div className={`mt-1 px-3.5 py-1.5 rounded-2xl border text-[11px] font-mono font-black uppercase ${
              currentPlan === "Voyager Elite Guardian"
                ? "bg-blue-500/10 border-blue-500/20 text-blue-500 shadow-sm"
                : currentPlan === "State/Diplomat Enterprise"
                  ? "bg-purple-500/10 border-purple-500/20 text-purple-500 shadow-sm"
                  : "bg-gray-100 dark:bg-slate-900 border-gray-200 dark:border-slate-800 text-gray-500 dark:text-gray-400"
            }`}>
              ⚡ {currentPlan}
            </div>
          </div>

          {/* Global save notifications */}
          <AnimatePresence>
            {saveBanner && (
              <motion.span
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="px-3 py-1.5 bg-emerald-500 text-white font-mono font-bold text-xs rounded-lg shadow-md flex items-center gap-1.5 h-fit"
              >
                <ShieldCheck className="h-4.5 w-4.5 animate-pulse" /> Telemetry Synced✓
              </motion.span>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Profile splits */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left">
        
        {/* Left Side Navigation List */}
        <div className="lg:col-span-3 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0">
          {[
            { id: "details", label: "My Travel Itinerary", icon: User },
            { id: "medical", label: "Medical Parameters", icon: Heart },
            { id: "guardian", label: "Guardian Sync Mode", icon: Shield },
            { id: "security", label: "Local Crypt-Locks", icon: Settings }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`p-3.5 rounded-xl border font-bold text-xs cursor-pointer flex items-center gap-2.5 shrink-0 transition-all text-left ${
                activeTab === item.id 
                  ? "bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-500/10" 
                  : "bg-white dark:bg-gray-950 border-gray-100 dark:border-gray-900 text-gray-600 dark:text-gray-400 hover:border-gray-200"
              }`}
            >
              <item.icon className="h-4.5 w-4.5 shrink-0" />
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Right Side Settings Area */}
        <div className="lg:col-span-9 bg-white dark:bg-gray-950 p-6 rounded-2xl border border-gray-100 dark:border-gray-900 shadow-xs">
          
          <AnimatePresence mode="wait">
            
            {activeTab === "details" && (
              <motion.div
                key="details"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white">Active Travel Itinerary Parameters</h3>
                  <p className="text-xs text-gray-400 font-mono">Used by the risk engine to auto forecast weather and travel risks</p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1 block">
                      <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Traveler Display Name</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium"
                      />
                    </div>
                    <div className="space-y-1 block">
                      <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Mobile Phone Coordinate</label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium"
                      />
                    </div>
                  </div>

                  <div className="space-y-1 block">
                    <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Notification Email Node</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium"
                    />
                  </div>

                  <div className="space-y-1 block">
                    <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Active Travel Itinerary Path & Dates</label>
                    <textarea
                      value={itinerary}
                      onChange={(e) => setItinerary(e.target.value)}
                      rows={3}
                      className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium font-sans resize-none"
                    />
                  </div>

                  <button
                    onClick={saveTravelParameters}
                    className="py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer border border-transparent shadow shadow-blue-500/10"
                  >
                    <Save className="h-4 w-4" /> Save Travel Parameters
                  </button>

                </div>
              </motion.div>
            )}

            {activeTab === "medical" && (
              <motion.div
                key="medical"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white">Emergency Medical Information Card</h3>
                  <p className="text-xs text-gray-400 font-mono">Presented block coordinates to medical first responders during critical SOS beacons</p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  
                  <div className="space-y-1 block">
                    <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Blood Type Group</label>
                    <input
                      type="text"
                      value={bloodType}
                      onChange={(e) => setBloodType(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-semibold"
                    />
                  </div>

                  <div className="space-y-1 block">
                    <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Severe Allergies (e.g. food, antibiotics, penicillin)</label>
                    <input
                      type="text"
                      value={allergies}
                      onChange={(e) => setAllergies(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium"
                    />
                  </div>

                  <div className="space-y-1 block">
                    <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Regular Prescribed Medications</label>
                    <textarea
                      value={meds}
                      onChange={(e) => setMeds(e.target.value)}
                      rows={2}
                      className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-medium font-sans resize-none"
                    />
                  </div>

                  <button
                    onClick={saveMedicalParameters}
                    className="py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer border border-transparent shadow shadow-blue-500/10"
                  >
                    <Save className="h-4 w-4" /> Save Medical Parameters Card
                  </button>

                </div>
              </motion.div>
            )}

            {activeTab === "guardian" && (
              <motion.div
                key="guardian"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white">Family Guardian Sync & Tracking Space</h3>
                  <p className="text-xs text-gray-400 font-mono">Applies silent background telemetry synchronization with registered family members</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  
                  {/* Setup parameters */}
                  <div className="md:col-span-7 space-y-4 text-xs font-sans">
                    
                    <div className="space-y-1 block">
                      <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Guardian Full Name</label>
                      <input
                        type="text"
                        value={guardianName}
                        onChange={(e) => setGuardianName(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1 block">
                        <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Guardian Phone</label>
                        <input
                          type="tel"
                          value={guardianPhone}
                          onChange={(e) => setGuardianPhone(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
                        />
                      </div>
                      <div className="space-y-1 block">
                        <label className="text-xs font-semibold text-gray-500 dark:text-gray-400">Guardian Email</label>
                        <input
                          type="email"
                          value={guardianEmail}
                          onChange={(e) => setGuardianEmail(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-850 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
                        />
                      </div>
                    </div>

                    <button
                      onClick={saveGuardianParameters}
                      className="py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer border border-transparent shadow shadow-blue-500/10"
                    >
                      <Save className="h-4 w-4" /> Save Guardian Sync Link
                    </button>

                  </div>

                  {/* Guardian Telemetry widget display */}
                  <div className="md:col-span-5 space-y-4">
                    <span className="text-[10px] font-bold font-mono text-gray-400 uppercase tracking-widest block">Active Guardian Node</span>
                    {guardUsers.map((user) => (
                      <div key={user.id} className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-gray-150 dark:border-gray-900 text-xs space-y-3">
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="font-extrabold text-blue-500 bg-blue-500/10 px-1.5 py-0.5 rounded uppercase">{user.relationship} Liaison</span>
                          <span className="text-gray-400">Sync: {user.lastActiveTime}</span>
                        </div>
                        <div className="space-y-0.5">
                          <span className="font-extrabold text-gray-800 dark:text-white font-display text-sm block">{user.name}</span>
                          <span className="text-gray-400 font-mono tracking-tight text-[11px] block">{user.phone}</span>
                        </div>

                        <div className="space-y-1.5 pt-1.5 border-t border-gray-150 dark:border-gray-800 text-[11px] block">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Last Active Checkpoint:</span>
                            <span className="font-semibold text-gray-700 dark:text-gray-300 truncate max-w-[140px] block">{user.lastActiveLocation}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Battery Level:</span>
                            <span className="font-mono text-emerald-500 font-bold flex items-center gap-1">
                              <BatteryCharging className="h-3.5 w-3.5" /> {user.batteryLevel}% Charge
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                </div>
              </motion.div>
            )}

            {activeTab === "security" && (
              <motion.div
                key="security"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white">Smart Credentials & Crypt-Locks</h3>
                  <p className="text-xs text-gray-400 font-mono">Protecting user status, location history and medical indices on device logs</p>
                </div>

                <div className="space-y-4 text-xs font-sans">
                  
                  {/* Biometric slider block */}
                  <div className="p-4 bg-gray-50/45 dark:bg-gray-900/30 rounded-xl border border-gray-100 dark:border-gray-900 flex justify-between items-center">
                    <div className="space-y-1 text-left">
                      <span className="font-bold text-gray-800 dark:text-white block">Biometric Lock Sync UI (FaceID/Fingerprint)</span>
                      <p className="text-[10px] text-gray-400">Requires local device scan prior to displaying critical SOS medical coordinates.</p>
                    </div>

                    <button
                      onClick={toggleBiometric}
                      className="text-blue-500 cursor-pointer p-1"
                    >
                      {biometricEnabled ? <ToggleRight className="h-9 w-9 text-blue-500 transition-transform" /> : <ToggleLeft className="h-9 w-9 text-gray-400 transition-transform" />}
                    </button>
                  </div>

                  {/* Two factor toggle */}
                  <div className="p-4 bg-gray-50/45 dark:bg-gray-900/30 rounded-xl border border-gray-100 dark:border-gray-900 flex justify-between items-center">
                    <div className="space-y-1 text-left">
                      <span className="font-bold text-gray-800 dark:text-white block">Two-Factor Authentication Core</span>
                      <p className="text-[10px] text-gray-400">Prompts SMS coordinate check triggers to verified emergency contacts during credential alterations.</p>
                    </div>

                    <button
                      onClick={toggleTwoFactor}
                      className="text-blue-500 cursor-pointer p-1"
                    >
                      {twoFactorEnabled ? <ToggleRight className="h-9 w-9 text-blue-500" /> : <ToggleLeft className="h-9 w-9 text-gray-400" />}
                    </button>
                  </div>

                  {/* Privacy state */}
                  <div className="p-4 bg-gray-50/45 dark:bg-gray-900/30 rounded-xl border border-gray-100 dark:border-gray-900 flex justify-between items-center">
                    <div className="space-y-1 text-left">
                      <span className="font-bold text-gray-800 dark:text-white block">Private Coordinates Masking (Extreme Privacy)</span>
                      <p className="text-[10px] text-gray-400">Stores location patterns strictly localized to browser memory block. Transmits zero telemetry unless SOS button fires.</p>
                    </div>

                    <button
                      onClick={togglePrivacyMode}
                      className="text-blue-500 cursor-pointer p-1"
                    >
                      {privacyMode ? <ToggleRight className="h-9 w-9 text-blue-500" /> : <ToggleLeft className="h-9 w-9 text-gray-400" />}
                    </button>
                  </div>

                  <div className="p-4 bg-blue-500/5 rounded-xl border border-blue-500/10 text-[11px] text-blue-600 dark:text-blue-400 space-y-1 inline-flex items-center gap-2">
                    <KeyRound className="h-5 w-5 text-blue-500 shrink-0" />
                    <p>
                      Credentials synced securely using SHA-256 standard localized containers.
                    </p>
                  </div>

                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </div>

      </div>

    </div>
  );
}
