import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, MapPin, AlertCircle, PhoneCall, Radio, Send, Users, Zap, CheckCircle, Award, Volume2, HardDrive, Bell } from "lucide-react";
import { IncidentReport, PriorityType } from "../types";

interface EmergencyCenterProps {
  incidents: IncidentReport[];
  currentLocation: string;
}

export default function EmergencyCenter({ incidents, currentLocation }: EmergencyCenterProps) {
  // Simulator tactical message log
  const [commsFeed, setCommsFeed] = useState<string[]>([
    "[SYSTEM SYNC] SafeVoyage Satellite Gateway holding standard 100% telemetry link.",
    "[POLICE HQ] Local precinct squad cars allocated along tourist central retail corridors.",
    "[ADVISORY] Automatic micro geofence broadcast verified at Times Square node."
  ]);
  const [broadcastInput, setBroadcastInput] = useState("");
  const [broadcastTarget, setBroadcastTarget] = useState("All Active Travelers");

  // Mock rescue squad telemetry
  const rescueTeams = [
    { name: "Alpha Moto Squad", type: "Tourist Police Patrol", location: "Sector 4 Corridor", status: "Active Transit", capacity: 85, phone: "+1 441 292" },
    { name: "Medical Rescue Team B", type: "Ambulance trauma unit", location: "Hospital Zone 2", status: "Dispatched", capacity: 95, phone: "+1 441 219" },
    { name: "Emergency Hazard Crew", type: "City Engineers Team", location: "State Grid Command", status: "Standby Hub", capacity: 100, phone: "+1 441 881" }
  ];

  const handleBroadcastMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastInput.trim()) return;

    setCommsFeed((prev) => [
      `[DISPATCHER BROADCAST to ${broadcastTarget}] ${broadcastInput}`,
      ...prev
    ]);
    setBroadcastInput("");
  };

  return (
    <div className="space-y-8 py-2 text-left font-sans">
      
      {/* Title section with live flash alert sign */}
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-150 dark:border-gray-900 text-left">
        <div className="space-y-1 block">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-500/10 text-red-500 font-mono text-[10px] font-bold uppercase">
            <Radio className="h-4.5 w-4.5 animate-pulse" /> Live Regional Emergency Feed Active
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold font-display text-gray-850 dark:text-white leading-tight">
            Emergency Response & Dispatch Center
          </h2>
          <p className="text-xs text-gray-400 font-mono">Autonomous municipal coordination and squad control deck</p>
        </div>

        <div className="flex gap-2 text-xs font-mono">
          <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-lg font-bold border border-emerald-500/15">
            Active Squads: 3/3
          </span>
          <span className="px-3 py-1 bg-blue-500/10 text-blue-500 rounded-lg font-bold border border-blue-500/15">
            Satellite Links: 100%
          </span>
        </div>
      </section>

      {/* Control Room Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left">
        
        {/* Left Side: Active Dispatch Events Feed List */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white dark:bg-gray-950 p-5 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-4 shadow-xs text-left">
            <div className="flex justify-between items-center border-b border-gray-100 dark:border-gray-900 pb-2.5">
              <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white uppercase tracking-tight">Active Dispatch Incident logs</h3>
              <span className="text-xs font-mono font-bold text-gray-400">Total session entries: {incidents.length}</span>
            </div>

            <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1">
              {incidents.length === 0 ? (
                <div className="p-8 border border-dashed border-gray-200 dark:border-gray-800 rounded-xl text-center text-xs text-gray-400 space-y-2">
                  <Shield className="h-10 w-10 text-gray-300 mx-auto" />
                  <p>All city areas holding basic safe levels. No active dispatch alerts reported.</p>
                </div>
              ) : (
                incidents.map((inc) => {
                  
                  // Priority Styling configuration
                  let headerColor = "border-l-4 border-l-emerald-500";
                  if (inc.priority === "Moderate") headerColor = "border-l-4 border-l-blue-500";
                  if (inc.priority === "High") headerColor = "border-l-4 border-l-orange-500";
                  if (inc.priority === "Critical") headerColor = "border-l-4 border-l-red-500 animate-pulse";

                  return (
                    <div key={inc.id} className={`p-4 bg-gray-50 dark:bg-gray-900/40 rounded-xl text-xs space-y-2.5 border border-gray-100/50 dark:border-gray-900 text-left ${headerColor}`}>
                      <div className="flex justify-between items-center text-[10px] font-mono">
                        <div className="flex gap-2 items-center">
                          <span className="font-extrabold uppercase text-blue-500">{inc.incidentType}</span>
                          <span className="text-gray-400">({inc.id})</span>
                        </div>
                        <span className="font-bold text-gray-400">{inc.timestamp}</span>
                      </div>

                      <div className="space-y-1 block">
                        <p className="font-semibold text-gray-800 dark:text-gray-150 font-sans">
                          Reporter: {inc.reporterName} • Phone: {inc.reporterPhone}
                        </p>
                        <p className="text-gray-500 dark:text-gray-400 font-sans italic">
                          &quot;{inc.description}&quot;
                        </p>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-gray-100 dark:border-gray-900">
                        <span className="font-mono text-gray-400 text-[10px]">CURRENT ROUTING STATUS:</span>
                        <span className="font-bold uppercase text-emerald-500 tracking-wider bg-emerald-500/10 px-2 py-0.5 rounded text-[9px]">
                          {inc.status}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Large dispatcher satellite broadcasting panel */}
          <div className="bg-white dark:bg-gray-950 p-5 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-4 shadow-xs text-left">
            <div>
              <h3 className="text-base font-extrabold font-display text-gray-850 dark:text-white uppercase tracking-tight">Active Warning Broadcast Transmitter</h3>
              <p className="text-[10px] text-gray-400 font-mono">Deploy satellite alert bulletins to all travelers inside the active node</p>
            </div>

            <form onSubmit={handleBroadcastMessage} className="space-y-4 text-xs font-sans">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Broadcast Targets</label>
                  <select
                    value={broadcastTarget}
                    onChange={(e) => setBroadcastTarget(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-xs cursor-pointer"
                  >
                    <option value="All Active Travelers" className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">All Active Travelers ({currentLocation})</option>
                    <option value="Only Solo Travelers" className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">Only Solo Travelers inside Danger bounds</option>
                    <option value="Active Rescue Moto Squads" className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">Active Rescue Moto Squads</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block">Warning Broadcast Type</label>
                  <select
                    className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-xs cursor-pointer"
                  >
                    <option className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">Urgent Geo-Fence Watch</option>
                    <option className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">General Weather advisory</option>
                    <option className="bg-white dark:bg-gray-950 text-gray-850 dark:text-white">Sovereign Law Change Advisory</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 block font-sans">Warning Message Content</label>
                <div className="flex gap-2.5">
                  <input
                    type="text"
                    value={broadcastInput}
                    onChange={(e) => setBroadcastInput(e.target.value)}
                    placeholder="e.g. Extreme commute crowds logged. Pocket-thieves flagged near exit ramps..."
                    required
                    className="flex-1 p-2.5 rounded-xl border border-gray-200 dark:border-gray-850 bg-gray-50/50 dark:bg-gray-900/50 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-sans"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold inline-flex items-center gap-1.5 cursor-pointer text-xs"
                  >
                    <Send className="h-4.5 w-4.5" /> Broadcast alert Bulletins
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

        {/* Right Side: Active Responders lists & Live telemetry log monitor */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Active squads tracker */}
          <div className="bg-white dark:bg-gray-950 p-5 rounded-2xl border border-gray-100 dark:border-gray-900 space-y-4 shadow-xs text-left">
            <div>
              <h4 className="text-sm font-extrabold font-display text-gray-850 dark:text-white uppercase tracking-tight">Active Responders Telemetry</h4>
              <p className="text-[10px] text-gray-400 font-mono">Monitoring capacity and mobile cellular link feeds</p>
            </div>

            <div className="space-y-3">
              {rescueTeams.map((team, idx) => (
                <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl space-y-2 border border-gray-100 dark:border-gray-900 text-xs">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="font-extrabold text-blue-500">{team.status}</span>
                    <span className="text-gray-400">{team.location}</span>
                  </div>

                  <div className="space-y-0.5 block">
                    <span className="font-bold text-gray-800 dark:text-gray-150 font-sans block">{team.name}</span>
                    <span className="text-gray-400 font-sans text-[11px] block">{team.type} • Contact: {team.phone}</span>
                  </div>

                  {/* Range indicator limit */}
                  <div className="w-full bg-gray-100 dark:bg-gray-850 rounded-full h-1.5 mt-1">
                    <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${team.capacity}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* live running feed monitor console log */}
          <div className="bg-black/90 text-emerald-400 p-4 rounded-xl font-mono text-[10px] leading-relaxed select-none space-y-2">
            <div className="flex justify-between items-center border-b border-emerald-900 pb-1.5 text-emerald-500 font-bold uppercase tracking-wider">
              <span>Dispatcher Running Telemetry Feed</span>
              <span className="animate-ping h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </div>

            <div className="space-y-1 overflow-y-auto max-h-[140px] scrollbar-thin">
              {commsFeed.map((feed, idx) => (
                <p key={idx} className="break-all">
                  {feed}
                </p>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
