import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Intercept and suppress benign Vite WebSocket HMR errors expected in this sandbox environment
if (typeof window !== "undefined") {
  window.addEventListener("unhandledrejection", (event) => {
    const msg = event.reason?.message || "";
    const stack = event.reason?.stack || "";
    if (
      msg.includes("WebSocket") || 
      msg.includes("vite") || 
      stack.includes("WebSocket") || 
      stack.includes("vite")
    ) {
      event.preventDefault();
      event.stopPropagation();
      console.debug("Muffled benign HMR websocket error:", msg);
    }
  });

  window.addEventListener("error", (event) => {
    const msg = event.message || "";
    if (msg.includes("WebSocket") || msg.includes("vite")) {
      event.preventDefault();
      event.stopPropagation();
      console.debug("Muffled benign HMR error:", msg);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
