import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Sparkles, MessageSquare, Compass, AlertTriangle, Users, Settings, Volume2, Moon, Sun, Clock, PhoneCall, Radio, Heart, MapPin, Search, Check, X, ShieldAlert, Award } from "lucide-react";
import LandingPage from "./components/LandingPage";
import AIAssistant from "./components/AIAssistant";
import SafetyDashboard from "./components/SafetyDashboard";
import IncidentReporting from "./components/IncidentReporting";
import RiskPrediction from "./components/RiskPrediction";
import EmergencyCenter from "./components/EmergencyCenter";
import ProfileManagement from "./components/ProfileManagement";
import { IncidentReport } from "./types";

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("dashboard");
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [currentLocation, setCurrentLocation] = useState<string>("Times Square, New York");
  const [utcTime, setUtcTime] = useState<string>("");
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);

  // Dynamic user data linking from LocalStorage for professional layout
  const [travelerName, setTravelerName] = useState<string>(() => localStorage.getItem("traveler_name") || "Alexis Carter");
  const [userPlan, setUserPlan] = useState<string>(() => localStorage.getItem("userPlan") || "Voyager Solo");
  const [isEditingLoc, setIsEditingLoc] = useState<boolean>(false);
  const [locInput, setLocInput] = useState<string>("Times Square, New York");

  useEffect(() => {
    const handleStorageSync = () => {
      setTravelerName(localStorage.getItem("traveler_name") || "Alexis Carter");
      setUserPlan(localStorage.getItem("userPlan") || "Voyager Solo");
    };
    window.addEventListener("storage", handleStorageSync);
    // Periodically sync just in case
    const interval = setInterval(handleStorageSync, 1000);
    return () => {
      window.removeEventListener("storage", handleStorageSync);
      clearInterval(interval);
    };
  }, []);

  // Global Incidents List synced across the client session
  const [incidents, setIncidents] = useState<IncidentReport[]>([
    {
      id: "rep-initial-1",
      reporterName: "Sarah Jenkins",
      reporterPhone: "+1 (555) 102-392",
      incidentType: "Theft",
      description: "Purse snatched while ordering coffee at Times Square Starbucks. Suspect fled down 42nd St subway entrance, carrying a black thermal jacket.",
      location: "Times Square, New York",
      contactEmergencyName: "Mark Jenkins (Brother)",
      priority: "Moderate",
      riskScore: 48,
      summary: "Incident classified as moderate property crime. Low ongoing bodily harm risk. Emergency units notified to watch subway platforms.",
      guideInstructions: "1. Lock credit cards using your bank card application immediately.\n2. Do NOT pursue the thief under any conditions.\n3. SafeVoyage Approved retailer 'Central Hotel' is 120m away - wait in their staffed lobby.",
      recommendedAuthority: "Transit Police Command Area 2",
      status: "Dispatched",
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toLocaleString()
    },
    {
      id: "rep-initial-2",
      reporterName: "David Vance",
      reporterPhone: "+1 (555) 881-224",
      incidentType: "Medical Emergency",
      description: "Chest tightness, severe hyperventilation near central park entrance. Citizen sitting on green bench, needs immediate check-up.",
      location: "Central Park East, New York",
      contactEmergencyName: "Linda Vance (Wife)",
      priority: "High",
      riskScore: 78,
      summary: "Medical incident logged. High priority triage. Ambulance unit dispatch routing established within 1.5 minutes.",
      guideInstructions: "1. Sit upright, take slow, deep diaphragmatic breaths.\n2. Keep your device screen unlocked with your emergency medical card showing.\n3. First response squad Alpha Moto is en route.",
      recommendedAuthority: "City EMS Ambulance Squad 4",
      status: "In Progress",
      timestamp: new Date(Date.now() - 10 * 60 * 1000).toLocaleString()
    }
  ]);

  // Keep UTC Time updated
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setUtcTime(now.toUTCString().replace("GMT", "UTC"));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Check health / system api connectivity
  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await fetch("/api/health");
        if (res.ok) {
          const data = await res.json();
          setHasApiKey(data.hasApiKey);
        }
      } catch (e) {
        console.warn("Express backend health link unavailable, running in local memory co-pilot mode.");
      }
    };
    checkHealth();
  }, []);

  // Update light/dark html tag styling
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [isDarkMode]);

  // Tab configurations
  const navigationItems = [
    { id: "dashboard", label: "Smart Dashboard", icon: Compass },
    { id: "landing", label: "Overview", icon: Shield },
    { id: "assistant", label: "Safety AI Companion", icon: MessageSquare },
    { id: "reporting", label: "SOS Reporting", icon: AlertTriangle },
    { id: "prediction", label: "Predictive Analytics", icon: Users },
    { id: "emergency", label: "Emergency Control", icon: Radio },
    { id: "profile", label: "Tourist Profile", icon: Settings }
  ];

  return (
    <div className="min-h-screen transition-colors duration-500 bg-[#FAF8F5] dark:bg-[#070B1E] text-slate-800 dark:text-gray-100 flex flex-col justify-between relative overflow-hidden bg-grid-pattern selection:bg-blue-600/20">
      
      {/* Dynamic Security Ambient mesh network glows */}
      <div className="absolute top-[-10%] left-[5%] h-[500px] w-[500px] rounded-full bg-gradient-to-tr from-blue-500/10 to-indigo-500/5 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: "12s" }} />
      <div className="absolute bottom-[20%] right-[-10%] h-[600px] w-[600px] rounded-full bg-gradient-to-br from-emerald-500/5 to-indigo-550/10 blur-[130px] pointer-events-none animate-pulse" style={{ animationDuration: "16s" }} />
      <div className="absolute top-[25%] right-[20%] h-[450px] w-[450px] rounded-full bg-gradient-to-tr from-amber-500/8 to-rose-500/4 blur-[115px] pointer-events-none animate-pulse" style={{ animationDuration: "20s" }} />
      <div className="absolute top-[40%] left-[30%] h-[400px] w-[400px] rounded-full bg-blue-500/3 blur-[100px] pointer-events-none" />

      {/* Main Premium Floating Header */}
      <header className="sticky top-0 z-40 bg-white/85 dark:bg-[#070B1E]/85 backdrop-blur-md border-b border-gray-200/40 dark:border-slate-850/60 shadow-[0_2px_20px_rgba(3,6,17,0.02)] dark:shadow-[0_8px_30px_rgba(2,4,10,0.4)] transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-20 flex items-center justify-between gap-4">
            
            {/* Brand Logo & Tagline with state-of-the-art icon design */}
            <div 
              onClick={() => setCurrentTab("landing")}
              className="flex items-center gap-3 cursor-pointer select-none group shrink-0 lg:pr-2"
            >
              <div className="h-10.5 w-10.5 premium-icon-container bg-gradient-to-tr from-blue-650 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/15 group-hover:scale-105 transition-all duration-300">
                <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400 group-hover:stroke-[2.5px] transition-all" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-lg tracking-tight font-display text-gray-950 dark:text-white group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors">
                    Tourism
                  </span>
                  <span className="px-1.5 py-0.5 rounded-full text-[8px] font-mono font-bold tracking-widest uppercase bg-blue-500/10 text-blue-600 dark:text-indigo-400 border border-blue-500/15 animate-pulse">
                    ACTIVE
                  </span>
                </div>
                <p className="text-[8.5px] text-gray-400 dark:text-gray-400 font-mono tracking-widest uppercase leading-none mt-1">Autonomous Sentinel Matrix</p>
              </div>
            </div>

            {/* Premium Desktop Capsule Navigation Tabs with Sliding Pill Animation */}
            <nav className="hidden xl:flex items-center gap-1 bg-gray-100/50 dark:bg-slate-900/50 p-1.5 rounded-2xl border border-gray-200/40 dark:border-slate-800/50 shadow-inner relative overflow-visible">
              {navigationItems.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id)}
                    className={`px-4 py-2.5 rounded-xl text-[11.5px] font-extrabold font-sans cursor-pointer transition-all duration-300 flex items-center gap-2 relative z-10 group ${
                      isActive
                        ? "text-blue-600 dark:text-blue-400"
                        : "text-gray-500 hover:text-gray-950 dark:text-gray-400 dark:hover:text-gray-200"
                    }`}
                    id={`nav-tab-${item.id}`}
                  >
                    {isActive && (
                      <motion.div 
                        layoutId="activePill"
                        className="absolute inset-0 bg-white dark:bg-[#0c122c] shadow-[0_4px_14px_rgba(59,130,246,0.08)] border border-blue-500/20 dark:border-blue-500/30 rounded-xl -z-10"
                        transition={{ type: "spring", stiffness: 380, damping: 28 }}
                      />
                    )}
                    <item.icon className={`h-4 w-4 transition-transform duration-300 group-hover:scale-110 ${isActive ? "text-blue-650 dark:text-blue-450 stroke-[2.5px] drop-shadow-[0_0_8px_rgba(59,130,246,0.3)]" : "text-gray-400/80 group-hover:text-blue-500"}`} />
                    <span className={`tracking-tight ${isActive ? "font-extrabold" : "font-semibold"}`}>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Dynamic Interactive Status Widgets */}
            <div className="flex items-center gap-3.5 shrink-0">
              
              {/* Dynamic Location Picker & Coordinate telemetry right in Navbar */}
              <div className="hidden md:flex items-center gap-2">
                {isEditingLoc ? (
                  <div className="flex items-center gap-1.5 bg-gray-50 dark:bg-slate-900/80 p-1 rounded-xl border border-blue-500/50 shadow-inner">
                    <input
                      type="text"
                      className="bg-transparent text-xs text-gray-850 dark:text-white px-2 py-1 outline-none font-mono w-44 font-semibold"
                      value={locInput}
                      onChange={(e) => setLocInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          if (locInput.trim()) {
                            setCurrentLocation(locInput);
                          }
                          setIsEditingLoc(false);
                        }
                      }}
                      autoFocus
                    />
                    <button
                      onClick={() => {
                        if (locInput.trim()) {
                          setCurrentLocation(locInput);
                        }
                        setIsEditingLoc(false);
                      }}
                      className="p-1 text-emerald-500 hover:bg-emerald-500/10 rounded-lg cursor-pointer"
                    >
                      <Check className="h-3.5 w-3.5 font-bold" />
                    </button>
                    <button
                      onClick={() => setIsEditingLoc(false)}
                      className="p-1 text-red-400 hover:bg-red-450/10 rounded-lg cursor-pointer"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setLocInput(currentLocation);
                      setIsEditingLoc(true);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gray-50/50 hover:bg-gray-100/80 dark:bg-slate-900/35 dark:hover:bg-slate-900/75 border border-gray-200/25 dark:border-slate-800/80 text-[10px] font-mono text-gray-500 dark:text-gray-300 transition-colors cursor-pointer group shadow-xs"
                    title="Click to switch active SafeVoyage Node"
                  >
                    <span className="block h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <MapPin className="h-3.5 w-3.5 text-emerald-500 group-hover:translate-y-[-1px] transition-transform" />
                    <span className="font-bold text-gray-800 dark:text-gray-100">{currentLocation}</span>
                    <span className="text-[8.5px] text-gray-400 px-1 py-0.5 bg-gray-200/50 dark:bg-slate-800/50 rounded font-mono font-semibold">SYNC</span>
                  </button>
                )}
              </div>

              {/* Dynamic Traveler Identity Capsule linked to LocalStorage profile updates */}
              <div 
                onClick={() => setCurrentTab("profile")}
                className="hidden lg:flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-gray-55/35 hover:bg-gray-100/50 dark:bg-slate-900/35 dark:hover:bg-slate-900/75 border border-gray-200/20 dark:border-slate-800/70 text-xs font-sans cursor-pointer transition-all duration-300 group shadow-xs"
                title={`Active Plan: ${userPlan}. Click to manage settings.`}
              >
                <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-indigo-500/10 to-blue-500/10 flex items-center justify-center text-indigo-500 dark:text-blue-400 font-extrabold border border-indigo-500/15 group-hover:scale-105 transition-transform">
                  {travelerName.charAt(0).toUpperCase()}
                </div>
                <div className="text-left text-[10px]">
                  <p className="font-bold text-gray-850 dark:text-gray-200 leading-tight tracking-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {travelerName}
                  </p>
                  <p className="text-[9px] text-gray-500 dark:text-gray-400 font-mono tracking-wider uppercase mt-0.5 leading-none font-semibold flex items-center gap-1">
                    🛡️ {userPlan}
                  </p>
                </div>
              </div>

              {/* Live Clock HUD */}
              <div className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-50/50 dark:bg-slate-900/30 border border-gray-200/20 dark:border-slate-800 text-[10px] font-mono text-gray-500 shadow-xs">
                <Clock className="h-3.5 w-3.5 text-blue-400 animate-spin" style={{ animationDuration: "16s" }} />
                <span className="font-bold text-gray-750 dark:text-gray-300">{utcTime || "SYNCING..."}</span>
              </div>

              {/* Dark Mode selector */}
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-2.5 rounded-xl bg-gray-50 hover:bg-gray-150 dark:bg-slate-900/40 dark:hover:bg-slate-850/80 border border-gray-200/25 dark:border-slate-800 text-gray-500 hover:text-gray-850 dark:text-gray-300 cursor-pointer transition-all hover:scale-105 shadow-xs"
                title="Toggle Light/Dark Theme"
                id="theme-toggle-btn"
              >
                {isDarkMode ? <Sun className="h-4 w-4 text-amber-500 animate-pulse" /> : <Moon className="h-4 w-4 text-slate-500" />}
              </button>

              {/* Main critical SOS indicator tab shortcut */}
              <button
                onClick={() => setCurrentTab("reporting")}
                className="px-4.5 py-2 text-xs font-bold bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 active:scale-97 text-white rounded-xl shadow-md shadow-red-500/10 hover:shadow-lg hover:shadow-red-500/25 transition-all flex items-center gap-2 cursor-pointer border border-red-700/20 group relative overflow-hidden"
                id="header-urgent-sos-btn"
              >
                <div className="absolute inset-0 w-full h-full bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <AlertTriangle className="h-4 w-4 text-white animate-bounce" />
                <span className="tracking-widest uppercase font-black text-[9.5px]">SOS SYSTEM</span>
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Navigation Bar scrolling sub-rail */}
        <div className="xl:hidden flex items-center gap-2 p-2 bg-gray-50 dark:bg-[#070b1cb3] backdrop-blur-md overflow-x-auto border-t border-gray-150 dark:border-slate-900 scrollbar-none scrollbar-thin">
          {navigationItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`px-4 py-2 rounded-xl text-[10.5px] font-extrabold font-display uppercase tracking-wider cursor-pointer whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 border ${
                  isActive
                    ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-550/30 border-blue-650"
                    : "bg-white/50 dark:bg-slate-900/30 text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-slate-900/60 border-gray-200/50 dark:border-slate-800/50"
                }`}
              >
                <item.icon className={`h-3.5 w-3.5 ${isActive ? "stroke-[2.5px] text-white" : "text-gray-400/80"}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full relative z-10">
        
        {/* Urgent Live Alert Banner on Active Crime or Disaster reported */}
        {incidents.some(inc => inc.priority === "Critical") && (
          <div className="mb-6 p-4 rounded-xl bg-red-600 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shadow-md animate-pulse">
            <div className="flex gap-2.5 items-center">
              <AlertTriangle className="h-5 w-5 text-white shrink-0" />
              <div className="text-left text-xs">
                <p className="font-extrabold font-display">URGENT SATELLITE THREAT WARNING TRIGGERED</p>
                <p className="text-red-100">Critical Medical / Event tracking sequence inside node coordinate. Evacuation response and routing is currently active.</p>
              </div>
            </div>
            <button
              onClick={() => setCurrentTab("emergency")}
              className="px-3.5 py-1.5 rounded bg-white text-red-600 font-bold text-xs hover:bg-red-50 cursor-pointer"
            >
              Open Rescue Center
            </button>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.18 }}
          >
            {currentTab === "landing" && (
              <LandingPage onNavigate={setCurrentTab} isDarkMode={isDarkMode} />
            )}

            {currentTab === "dashboard" && (
              <SafetyDashboard currentLocation={currentLocation} />
            )}

            {currentTab === "assistant" && (
              <AIAssistant currentLocation={currentLocation} setCurrentLocation={setCurrentLocation} />
            )}

            {currentTab === "reporting" && (
              <IncidentReporting currentLocation={currentLocation} incidents={incidents} setIncidents={setIncidents} />
            )}

            {currentTab === "prediction" && (
              <RiskPrediction currentLocation={currentLocation} />
            )}

            {currentTab === "emergency" && (
              <EmergencyCenter incidents={incidents} currentLocation={currentLocation} />
            )}

            {currentTab === "profile" && (
              <ProfileManagement />
            )}
          </motion.div>
        </AnimatePresence>

      </main>

      {/* Corporate Grade Professional Footer */}
      <footer className="border-t border-gray-200/50 dark:border-slate-800/80 bg-white/60 dark:bg-[#030612]/60 backdrop-blur-md py-12 mt-12 relative z-10 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            
            {/* Leftmost Brand Bio Column */}
            <div className="space-y-4 md:col-span-2 text-left">
              <div className="flex items-center gap-2 select-none">
                <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                  <Shield className="h-4.5 w-4.5" />
                </div>
                <span className="font-extrabold text-base tracking-tight font-display text-gray-950 dark:text-white">
                  Tourism
                </span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm leading-relaxed">
                The next-generation autonomous sentinel defense network. Serving real-time telemetry, predictive threat matrices, global SOS coordination, and satellite backup. Engineered for modern high-performance traveler protection.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-gray-100 dark:bg-slate-900 border border-gray-200/20 dark:border-slate-800 text-[9px] font-mono text-gray-500">
                  🛰️ SatLink: Active
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-blue-500/5 dark:bg-blue-955/15 border border-blue-500/10 text-[9px] font-mono text-blue-500">
                  🔐 AES-GCM-256
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-500/5 dark:bg-emerald-955/15 border border-emerald-500/10 text-[9px] font-mono text-emerald-500">
                  ✓ GDTC compliant
                </span>
              </div>
            </div>

            {/* Quick Navigation Links */}
            <div className="space-y-3 text-left">
              <h4 className="text-xs font-bold font-mono tracking-wider text-gray-400 uppercase">Protection Network</h4>
              <ul className="space-y-2 text-xs font-medium">
                {navigationItems.slice(0, 4).map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => setCurrentTab(item.id)}
                      className={`hover:text-blue-500 transition-colors cursor-pointer ${
                        currentTab === item.id ? "text-blue-500 font-bold" : "text-gray-450 dark:text-gray-400"
                      }`}
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Security Systems Links */}
            <div className="space-y-3 text-left">
              <h4 className="text-xs font-bold font-mono tracking-wider text-gray-400 uppercase">Emergency Control</h4>
              <ul className="space-y-2 text-xs font-medium">
                {navigationItems.slice(4).map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => setCurrentTab(item.id)}
                      className={`hover:text-blue-500 transition-colors cursor-pointer ${
                        currentTab === item.id ? "text-blue-500 font-bold" : "text-gray-450 dark:text-gray-400"
                      }`}
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
                <li>
                  <button
                    onClick={() => setCurrentTab("reporting")}
                    className="text-red-500 font-bold hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span className="inline-block w-2 h-2 rounded-full bg-red-500 animate-pulse" /> Launch SOS Trigger
                  </button>
                </li>
              </ul>
            </div>

          </div>

          {/* Copyright & System Status bottom banner */}
          <div className="pt-8 border-t border-gray-250/20 dark:border-slate-800/60 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] font-mono text-gray-400">
            <p>© 2026 Tourism Sentinel Systems Association. All rights protected under global emergency maritime laws.</p>
            <div className="flex items-center gap-4">
              <span>Node Latency: <strong className="text-emerald-500">14ms (OPTIMAL)</strong></span>
              <span>Active Sentinel Node: <strong className="text-blue-400 uppercase">{currentLocation}</strong></span>
            </div>
          </div>

        </div>
      </footer>

      {/* Floating Tactical SOS Action Trigger (Present on all sections but reporting itself) */}
      {currentTab !== "reporting" && (
        <div className="fixed bottom-6 right-6 z-40 group">
          <button
            onClick={() => setCurrentTab("reporting")}
            className="h-14 w-14 rounded-full bg-gradient-to-r from-red-600 to-orange-500 text-white flex items-center justify-center shadow-xl shadow-red-500/20 hover:scale-105 active:scale-95 cursor-pointer transition-transform relative border-2 border-white/20"
            title="Fire instant absolute emergency SOS countdown"
            id="floating-sos-action-btn"
          >
            <AlertTriangle className="h-6 w-6 animate-pulse" />
            <span className="absolute bottom-12 right-0 whitespace-nowrap bg-red-600 text-white text-[10px] font-bold tracking-widest px-2.5 py-1 rounded shadow-md scale-0 group-hover:scale-100 transition-all font-mono uppercase">
              ACTIVATE SOS
            </span>
          </button>
        </div>
      )}

    </div>
  );
}
