export type PriorityType = "Low" | "Moderate" | "High" | "Critical";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  fileAttached?: {
    name: string;
    type: string;
    size: number;
    url: string;
  };
}

export interface IncidentReport {
  id: string;
  reporterName: string;
  reporterPhone: string;
  incidentType: string;
  description: string;
  location: string;
  contactEmergencyName: string;
  priority: PriorityType;
  riskScore: number;
  summary: string;
  guideInstructions: string;
  recommendedAuthority: string;
  status: "Reported" | "AI Checked" | "Dispatched" | "In Progress" | "Resolved";
  timestamp: string;
  audioRecorded?: boolean;
}

export interface SafetyScoreReport {
  safetyScore: number;
  threatLevel: string;
  crimeForecasting: string;
  crowdRisk: string;
  weatherHazard: string;
  safeZones: string[];
  alertBanner: string;
  instructions: string;
  recommendedHotelsArea?: string;
}

export interface GuardModeUser {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  email: string;
  lastActiveLocation: string;
  lastActiveTime: string;
  batteryLevel: number;
  safetyScoreCurrent: number;
  activeIncidents: number;
}
