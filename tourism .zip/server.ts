import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Lazy init Gemini SDK
const getKey = () => {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === "MY_GEMINI_API_KEY") {
    return null;
  }
  return key;
};

const getGenAI = () => {
  const key = getKey();
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
};

// API: Health Check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!getKey(),
    timestamp: new Date().toISOString()
  });
});

// Mock/Fallback data when API Key is missing so the platform is highly robust and fully previewable
const FALLBACK_CHAT_RESPONSE = "This is a local safety guidance response. To enable real conversational AI safety analysis, please configure your actual GEMINI_API_KEY in the Secrets panel. Always memorize emergency numbers: 112 / 911 depending on your country.";

// API Endpoint: Safety Score and Risk Forecast Analysis
app.post("/api/safety/score", async (req, res) => {
  const { location, weather, crowdDensity } = req.body;
  const targetLocation = location || "New York City Times Square";

  const ai = getGenAI();
  if (!ai) {
    // Return smart calculated fallback response Mock (Simulating safety analytics structure)
    const baseScore = Math.floor(Math.random() * 20) + 75; // 75 - 95
    return res.json({
      safetyScore: baseScore,
      threatLevel: baseScore > 85 ? "Low" : "Medium",
      crimeForecasting: "In " + targetLocation + ", pickpocketing has a transient minor increase during crowded evening periods. Overall, violent crime indices remain extremely low.",
      crowdRisk: crowdDensity === "high" ? "High crowding detected. Maintain situational awareness and watch personal belongings closely." : "Low crowd risk. Smooth flow of pedestrian corridors.",
      weatherHazard: weather ? `Current weather trends indicate: ${weather}. Normal city advisories apply.` : "Clear visibility, optimal conditions for urban transit.",
      safeZones: [
        "Tourist Information Center Plaza",
        "Central Police Command Substation",
        "Safe Haven Certified Retail Outlets"
      ],
      alertBanner: "No active critical advisories. Stay mindful of personal devices in public transit hubs.",
      instructions: "Keep your offline emergency kit downloaded, maintain a low profile in unfamiliar peripheral blocks at late hours, and use official ride-hailing services.",
      recommendedHotelsArea: "Tourism Gold Certified hospitality radius within 500 meters."
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Perform a detailed security, crowd, weather, and safety risk assessment for tourist destination "${targetLocation}". Present parameters matching current local trends or typical risk structures. Current context indicators: weather is ${weather || "Clear"}, crowd density context is ${crowdDensity || "Medium"}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            safetyScore: { type: Type.INTEGER, description: "Safety index out of 100, where 100 is perfectly secure." },
            threatLevel: { type: Type.STRING, description: "Threat profile: Low, Medium, High, or Severe" },
            crimeForecasting: { type: Type.STRING, description: "AI predictive narrative regarding local crime, scams, or thefts." },
            crowdRisk: { type: Type.STRING, description: "Pedestrian density hazards, stampede alerts, or localized overcrowding risks." },
            weatherHazard: { type: Type.STRING, description: "Weather constraints or natural hazard alerts." },
            safeZones: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3 safest micro-locations nearby, hospital, or police stations." },
            alertBanner: { type: Type.STRING, description: "A one-sentence urgent warning if any, or general status banner if safe." },
            instructions: { type: Type.STRING, description: "Actionable strategic traveler safety behavior recommendations." },
            recommendedHotelsArea: { type: Type.STRING, description: "Recommended lodging zones with high safety indices." }
          },
          required: ["safetyScore", "threatLevel", "crimeForecasting", "crowdRisk", "weatherHazard", "safeZones", "instructions"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("Safety analysis failed:", error);
    res.status(500).json({ error: error?.message || "Failed to call Gemini AI safety scanner." });
  }
});

// API Endpoint: Intelligent Live Chat and Local Travel Advisory Assistant
app.post("/api/assistant/chat", async (req, res) => {
  const { messages, location } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid request payload. 'messages' array is required." });
  }

  const ai = getGenAI();
  if (!ai) {
    return res.json({
      text: `${FALLBACK_CHAT_RESPONSE}\n\nYou said: "${messages[messages.length - 1]?.content || ""}"`
    });
  }

  try {
    // Format conversation history for Gemini
    const systemPrompt = `You are the Tourism Tourist Safety Assistant, an elite, reassuring, conversational safety guide for international travelers.
Your top priority is tourist survival, health, legal comfort, security, and smart routing.
Current tourist location context: ${location || "Global Coordinates"}.
If the user reports a serious ongoing emergency (e.g., 'I am being chased', 'Medical heart attack'), reply in high-priority, actionable, and compassionate language, giving immediate clear, local emergency standard directions (e.g. Call emergency service, seek shelter, look for nearest official police).
Otherwise, offer precise crime forecasting, weather tips, safe hotel suggestions, and helpful localized tips. Keep suggestions highly realistic, scannable, and formatted as beautiful markdown. Always cite actual standard processes if possible!`;

    // Map systemPrompt and user messages
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        { role: "user", parts: [{ text: systemPrompt }] },
        ...messages.map((m: any) => ({
          role: m.role === "user" ? "user" : "model",
          parts: [{ text: m.content }]
        }))
      ]
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Chat failure:", error);
    res.status(500).json({ error: error?.message || "Internal server error on safety chatbot service." });
  }
});

// API Endpoint: Real-Time Incident Reporting and Autonomous AI Triage Classified Workflow
app.post("/api/incidents/submit", async (req, res) => {
  const { incidentType, description, location, reporterName, reporterPhone, contactEmergencyName, audioRecorded, imageBase64 } = req.body;

  const ai = getGenAI();
  if (!ai) {
    // Fallback classification logic (Deterministic Smart Mock)
    const criticalKeywords = ["weapon", "fire", "heart", "bleeding", "kill", "broken", "critical", "dying", "unconscious"];
    const highKeywords = ["theft", "stolen", "robbed", "car", "purse", "passport", "harass", "threaten", "lost"];
    
    let priority = "Moderate";
    let riskScore = 45;
    const lowerDesc = (description || "").toLowerCase();
    
    if (criticalKeywords.some(kw => lowerDesc.includes(kw))) {
      priority = "Critical";
      riskScore = 92;
    } else if (highKeywords.some(kw => lowerDesc.includes(kw))) {
      priority = "High";
      riskScore = 74;
    } else if (lowerDesc.length < 15) {
      priority = "Low";
      riskScore = 18;
    }

    return res.json({
      category: incidentType || "General Safety",
      priority: priority,
      riskScore: riskScore,
      summary: `Automated Incident Logged. Reporter ${reporterName || "Anonymous"} indicated a potential state of incident alert. Location tags: ${location || "Current Coordinate"}.`,
      guideInstructions: "1. Ensure you are in a brightly-lit, highly public, secure area.\n2. Keep your mobile device safe and lock any baggage.\n3. A professional dispatcher is reviewing this report.",
      recommendedAuthority: priority === "Critical" ? "State Emergency Dispatch & Emergency Medical Services" : "Municipal Tourist Police Headquarters"
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Analyze the following tourist incident report and provide critical classification and triage guidance:
Report Type: ${incidentType}
Location: ${location}
Description: ${description}
Has Voice Attachment: ${!!audioRecorded}
Has Image Attachment: ${!!imageBase64}

Classify priority exactly as one of: Low, Moderate, High, Critical. Offer deep risk assessment scoring and prompt guidelines.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: "Refined category for this incident." },
            priority: { type: Type.STRING, description: "Must be exactly Low, Moderate, High, or Critical." },
            riskScore: { type: Type.INTEGER, description: "Severity index between 0 and 100 based on urgency." },
            summary: { type: Type.STRING, description: "AI concise summary of the traveler situation." },
            guideInstructions: { type: Type.STRING, description: "Step-by-step immediate safety steps the tourist should complete." },
            recommendedAuthority: { type: Type.STRING, description: "Which municipal, police, medical or ocean guard division should be contacted." }
          },
          required: ["category", "priority", "riskScore", "summary", "guideInstructions", "recommendedAuthority"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("Incident triage classification failed:", error);
    res.status(500).json({ error: error?.message || "AI triage categorization service offline." });
  }
});

// Configure Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Tourism Backend] Run environment: ${process.env.NODE_ENV || "development"}`);
    console.log(`[Tourism Backend] Listening securely on port http://0.0.0.0:${PORT}`);
  });
}

startServer();
